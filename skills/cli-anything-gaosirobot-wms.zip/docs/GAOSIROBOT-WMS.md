# GAOSIROBOT-WMS — Software-Specific SOP (cli-anything)

## 1. What the software is

宁波高斯 WMS (`gaosirobot-wms-app`) is a **uni-app + Vue 3 + TypeScript mobile WMS client**
(H5 / Android PDA / WeChat mini-program). The GUI is a thin layer over a REST backend:

- Transport: `src/http/http.ts` (uni.request wrapper) + `src/http/interceptor.ts`
- API surface: `src/api/*.ts` (one file per business domain)
- State: Pinia stores — `src/store/token.ts` (auth), `src/utils/serverConfig.ts` (server env)
- Response envelope: `{ code, data, msg | message }`, success `code ∈ {0, 200}`,
  `code 250` = "confirm dialog then proceed" (GUI shows modal, then uses `data`),
  `code 401` = re-login. HTTP 200–299 required.
- Auth: single-token mode (`VITE_AUTH_MODE = 'single'`); `POST /MobileLogin`
  returns a token string; requests carry `Authorization: Bearer <token>`.
  Double-token mode (`accessToken`/`refreshToken`) is supported by the client code
  and mirrored in the CLI.
- Server presets (runtime switchable, confirmed by user):
  - production（正式）`http://211.91.60.61:30001`
  - test（测试）`http://211.91.60.61:20001`
  - custom: protocol + host + apiPort (default 30001)

## 2. GUI page → API mapping (source of truth for the CLI)

| GUI page (src/pages) | API call |
| --- | --- |
| 登录 | `POST /MobileLogin` (header `username`), `GET /getInfo`, `POST /LogOut` |
| 采购收料 | `GET /MyClass/MyApi/GetDeliveryDoc?cCode=`, `GET /MyClass/MyApi/GetPackageMin?PackCode=`, `GET /MyClass/MyApi/GetPackageMax?Id=`, `POST /MyClass/MyApi/AddArrivalVouch` |
| 采购入库 | `GET /MyClass/MyApi/GetPosition?cPosCode=`, `GET /MyClass/MyMethod/GetPositionList?cPosName=`, `GET /MyClass/MyApi/GetPackageMin_CGRK?PackCode=&cPosCode=`, `GET /MyClass/MyApi/GetPackageMax_CGRK`, `POST /MyClass/MyApi/AddCGRK` |
| 采购退货/拒收 | `GET /MyClass/MyApi/GetPackageMin_CGTH`, `POST /MyClass/MyApi/AddCGTH`, `GET /MyClass/MyApi/GetPackageMin_CGJS`, `POST /MyClass/MyApi/AddCGJS` |
| 生产调拨 | `GET /MyClass/MyMethod/GetMomOrderDetail?moCode=`, `POST /MyClass/MyApi/ScanDBDPackCode`, `POST /MyClass/MyApi/AddDBDMom`, `GET /MyClass/MyApi/ScanDBDPackCodeBack` |
| 非生产调拨 | `GET /MyClass/MyMethod/GetWareHouseList`, `POST /MyClass/MyApi/ScanDBDPackCode2`, `POST /MyClass/MyApi/AddDBD` |
| 成品入库 | `GET /MyClass/MyApi/GetPosition_CCPRK`, `GET /MyClass/MyApi/GetMaterial_CCPRK?barCodeUnder=`, `POST /MyClass/MyApi/AddCCPRK` |
| 发货计划 (APP) | `GET /MyClass/MyApi/GetU9CShipPlanList`, `POST /MyClass/MyApi/AddXSCK?shipPlanCode=` (query, empty body) |
| 销售出库 (H5) | `GET /MyClass/MyApi/GetWmsXSCKList`, `POST /MyClass/MyApi/ConfirmXSCK?...` (query, empty body) |
| 包装追溯 | `GET /MyClass/MyApi/GetPackageMinStaus?PackCode=` (backend typo kept as-is) |
| 系统消息 | `GET /SysUserMsg/mylist?isRead=&msgTypes=`, `POST /SysUserMsg/read/{msgId}/{msgType}` |
| 系统配置/字典 | `GET /system/config/{id}`, `GET /system/config/configKey/{key}`, `GET /system/dict/data/type/{type}` |

## 3. Submission payload shapes (from `src/api/types/*`)

- **AddCGRKRequest**: `dDate, cVenCode, cVenName, cWhCode, createUserCode, createUserName, datas[{cInvCode, cInvName, autoIdSrm, poNo, poRowId, packCode, packCodeMax, cBatch, iQuantity, cInvStd, cComUnitName, cPosCode}]`
- **AddArrivalVouch (GRN)**: `cCodeSRM, cMemo, createUserCode, createUserName, cVenCode, cVenName, datas[{cBatch, cInvCode, cInvName, iQuantity, packCode, poNo, poRowId, cInvStd, cComUnitName}], dDate, dDateSRM, phone`
- **AddDBDMomRequest** (production transfer): `dDate, cWhCodeOut, cWhCodeIn, moCode, createUserCode, createUserName, datas[{cInvCode, cInvName, cInvStd, cComUnitName, packCode, packCodeMax, cPosCodeOut, cPosCodeIn, cBatch, iQuantity}]`
- **AddDBD** (warehouse transfer): `dDate, cWhCodeOut, cWhCodeIn, createUserCode, createUserName, datas[{cInvCode, cInvName, cInvStd, cComUnitName, packCode, packCodeMax, cBatch, iQuantity, cPosCodeOut, cPosCodeIn}]`
- **AddCCPRK** (finished inbound): `dDate, cWhCode, createUserCode, createUserName, datas[{cInvCode, cInvName, cInvStd, cComUnitName, cPosCode, cBatch, iQuantity, storageRack, barCode, barCodeUnder, moDId, moCode}]`
- **AddCGJS** (purchase reject): `dDate, cVenCode, cVenName, cReason, cMemo, createUserCode, createUserName, Datas[{cInvCode, cInvName, cInvStd, cComUnitName, arrivalVouchsAutoId, arrivalVouchCode, cCodeSRM, poNo, poRowId, packCode, packCodeMax, cBatch, iQuantity}]` (note capital `Datas`)
- **AddCGTH** (purchase return): `dDate, cReason, cMemo, createUserCode, createUserName, datas[{packCode, iQuantity}]`
- **ConfirmXSCK / AddXSCK**: query parameters (`dDate`, `createUserCode`, `createUserName`, `cCode` / `shipPlanCode`), empty body.
- **ScanDBDPackCode / ScanDBDPackCode2**: `{currentPackCode, packCodes[]}` (+ `cWhCodeOut, cWhCodeIn, cPosCodeIn` for the `2` variant).

## 4. CLI state model

The GUI is a *scan-accumulate-submit* workflow: worker scans packages into a list,
reviews it, then submits the document. The CLI mirrors this with a **session file**
(`~/.cli-anything/gaosirobot-wms/session.json`, override with `CLI_ANYTHING_WMS_SESSION`)
holding:

- `server`: base URL + environment (production / test / custom)
- `token`: single token string, or `{accessToken, refreshToken, ...}` (double mode)
- `user`: `getInfo` snapshot (`userName`, `nickName`) used as document creator
- `drafts`: per-workflow scan carts (`inbound`, `transfer`, `warehouse`, `finished`, `reject`, `return`)

**Auto-save rule**: every one-shot mutation (scan / draft mutation / submit / login /
server switch) persists the session before exit unless `--dry-run` is given.
`--dry-run` on a submit prints the exact payload and performs no request and no save.

## 5. Output contract

- Default: human-readable tables/lines.
- `--json` (global flag, top of command or `CLI_ANYTHING_JSON=1`): machine-readable
  `{"ok": true/false, "code": <business code>, "msg": "...", "data": ...}`.
- Exit codes: `0` success (250 confirms count as success with a notice), `1` error
  (HTTP/network/business failure), `2` usage error (Click).

## 6. Agent operating procedure

1. `server show` → confirm target environment; `server use <env> [--url]` + `server probe`.
2. `auth login -u <user>` (password via prompt or `WMS_PASSWORD`), `auth whoami`.
3. Query phase: read-only commands (`purchasing delivery`, `transfer mo`, `sales plans`, ...).
4. Build a document: repeated `scan` commands append to the draft; `draft show` to review.
5. `submit` to post; on success the draft is cleared automatically.
6. Never submit without reviewing the draft; use `--dry-run` to inspect the payload.
7. Raw escape hatch for anything unmapped: `api request GET /MyClass/MyApi/... --query k=v`.
