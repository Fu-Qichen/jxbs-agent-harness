"""Main CLI entry point — cli-anything-gaosirobot-wms.

Stateful harness for the Gaosi WMS backend (gaosirobot-wms-app).

- One-shot commands + interactive REPL (invoke with no arguments or ``repl``).
- ``--json`` global flag (or ``CLI_ANYTHING_JSON=1``) for agent consumption.
- ``--dry-run`` global flag: mutations do not touch the server (submits print
  the payload) and the session file is never persisted.
- Auto-save: every mutating one-shot command persists the session before exit
  unless ``--dry-run`` is active.
"""

from __future__ import annotations

import json
import os
import shlex
import sys

import click

from cli_anything.gaosirobot_wms import CLI_NAME, SOFTWARE, __version__
from cli_anything.gaosirobot_wms.core import auth
from cli_anything.gaosirobot_wms.core.client import (
    SERVER_PRESETS,
    WmsAuthError,
    WmsClient,
    WmsError,
    WmsTransportError,
)
from cli_anything.gaosirobot_wms.core.finished import (
    build_inbound_request as build_finished_request,
    get_material,
    get_recommended_position,
    submit_inbound as submit_finished,
)
from cli_anything.gaosirobot_wms.core.purchasing import (
    build_inbound_request,
    get_bin,
    get_delivery_note,
    get_package_max,
    get_package_min,
    inbound_scan,
    list_bins,
    submit_arrival,
    submit_inbound,
)
from cli_anything.gaosirobot_wms.core.returns import (
    build_reject_request,
    build_return_request,
    list_messages,
    package_status,
    read_message,
    reject_scan,
    return_scan,
    submit_reject,
    submit_return,
)
from cli_anything.gaosirobot_wms.core.sales import (
    confirm_outbound,
    list_outbounds,
    list_shipping_plans,
    submit_shipping_plan,
)
from cli_anything.gaosirobot_wms.core.session import DRAFT_GROUPS, Session
from cli_anything.gaosirobot_wms.core.transfer import (
    build_transfer_request,
    build_warehouse_request,
    get_mo_detail,
    list_warehouses,
    scan_pack,
    scan_pack_back,
    scan_warehouse_pack,
    submit_transfer,
    submit_warehouse_transfer,
)
from cli_anything.gaosirobot_wms.core.web import (
    get_grn_detail,
    get_purchase_inbound_detail,
    get_purchase_rejection_all,
    get_purchase_rejection_detail,
    get_purchase_return_all,
    get_purchase_return_detail,
    get_sales_outbound_detail,
    get_transfer_order_detail,
    get_nonproduction_transfer_detail,
    get_finished_inbound_detail,
    get_manufacturing_order_detail,
    list_grn,
    list_purchase_inbound,
    list_purchase_rejection,
    list_purchase_return,
    list_sales_outbound,
    list_manufacturing_order,
    list_transfer_order,
    list_nonproduction_transfer,
    list_finished_inbound,
    list_completion,
    list_inventory_report,
    list_inventory_report_sum,
    list_warehouse,
    list_material,
    list_supplier,
    list_bin,
    get_position_tree,
    list_user,
    list_role,
    list_dict_data,
    get_config,
    post_srm_inspect,
    delete_grn,
    delete_purchase_inbound,
    delete_purchase_rejection,
    delete_purchase_return,
    delete_finished_inbound,
    upload_cgrk_u9c,
    upload_xsck_u9c,
    upload_purchase_return_u9c,
    upload_transfer_u9c,
    upload_nonproduction_transfer_u9c,
    upload_ccprk_u9c,
    upload_completion_u9c,
    post_xsck_agv,
    post_ccprk_agv,
)
from cli_anything.gaosirobot_wms.core.web_auth import web_get_info, web_login, web_logout
from cli_anything.gaosirobot_wms.core.web_client import WebWmsClient
from cli_anything.gaosirobot_wms.utils.output import (
    emit_json,
    emit_value,
    fail,
    print_table,
    today,
)


# ---------------------------------------------------------------------------
# runtime plumbing
# ---------------------------------------------------------------------------


class Runtime:
    """Per-invocation state shared by all commands."""

    def __init__(self, json_mode: bool, dry_run: bool) -> None:
        self.json_mode = json_mode
        self.dry_run = dry_run
        self.session = Session()

    @property
    def logged_in(self) -> bool:
        return self.session.is_logged_in

    def client(self) -> WmsClient:
        if not self.session.base_url:
            fail("no server configured; run `server use <production|test|custom>`",
                 json_mode=self.json_mode)
        return WmsClient(self.session.base_url, self.session.token)

    def web_client(self) -> WebWmsClient:
        """Web admin client with tenant/userid/userName headers."""
        if not self.session.base_url:
            fail("no server configured; run `server use <production|test|custom>`",
                 json_mode=self.json_mode)
        wdata = self.session._data.get("web", {})
        return WebWmsClient(
            self.session.base_url,
            self.session.token,
            tenant_id=wdata.get("tenant_id", "tenant0"),
            user_id=wdata.get("user_id", 0),
            user_name=wdata.get("user_name", ""),
        )

    def notice(self, message: str) -> None:
        if not self.json_mode:
            click.echo(message, err=True)

    def save(self) -> None:
        """Auto-save the session after a one-shot mutation (suppressed by --dry-run)."""
        if self.dry_run:
            self.notice("(dry-run: session not saved)")
        else:
            self.session.save()

    def emit(self, data, notice: str | None = None) -> None:
        """Emit the last API result honoring --json; attach 250-confirm notices."""
        code = self._client_code
        msg = self._client_msg
        if notice and not self.json_mode:
            click.echo(f"NOTE: {notice}", err=True)
        if self.json_mode:
            emit_json(True, code, notice or msg, data)
        else:
            emit_value(data)

    def set_client_meta(self, client: WmsClient) -> None:
        self._client_code = client.last_code
        self._client_msg = client.last_msg

    _client_code: int | None = None
    _client_msg: str | None = None


class _ApiError(click.ClickException):
    pass


def api_call(rt: Runtime, fn, *args, **kwargs):
    """Run an API call, translating domain errors into clean CLI failures."""
    client = rt.client()
    try:
        result = fn(client, *args, **kwargs)
    except WmsAuthError as exc:
        fail(f"authentication expired (401): {exc.msg}; run `auth login`",
             code=401, json_mode=rt.json_mode)
    except WmsTransportError as exc:
        fail(f"network failure: {exc}", json_mode=rt.json_mode)
    except WmsError as exc:
        fail(f"API error {exc.code}: {exc.msg}", code=exc.code, data=exc.data,
             json_mode=rt.json_mode)
    except ValueError as exc:
        fail(str(exc), json_mode=rt.json_mode)
    rt.set_client_meta(client)
    return result


def web_api_call(rt: Runtime, fn, *args, **kwargs):
    """Run a web admin API call with WebWmsClient (tenant/userid headers)."""
    client = rt.web_client()
    try:
        result = fn(client, *args, **kwargs)
    except WmsAuthError as exc:
        fail(f"authentication expired (401): {exc.msg}; run `web auth login`",
             code=401, json_mode=rt.json_mode)
    except WmsTransportError as exc:
        fail(f"network failure: {exc}", json_mode=rt.json_mode)
    except WmsError as exc:
        fail(f"API error {exc.code}: {exc.msg}", code=exc.code, data=exc.data,
             json_mode=rt.json_mode)
    except ValueError as exc:
        fail(str(exc), json_mode=rt.json_mode)
    rt.set_client_meta(client)
    return result


def creator_args(rt: Runtime, user_code: str | None, user_name: str | None) -> tuple[str, str]:
    """Document creator: CLI options, else the login user snapshot."""
    user = rt.session.user or {}
    code = user_code or user.get("userName") or ""
    name = user_name or user.get("nickName") or user.get("userName") or ""
    if not code:
        fail("no creator available: pass --user-code/--user-name or run `auth login`",
             json_mode=rt.json_mode)
    return code, name


def load_json_argument(data: str | None, file) -> dict:
    if file is not None:
        try:
            return json.load(file)
        except ValueError as exc:
            fail(f"invalid JSON file: {exc}")
    if data:
        try:
            return json.loads(data)
        except ValueError as exc:
            fail(f"invalid JSON: {exc}")
    fail("no payload: pass JSON via --data or --file")


@click.group()
@click.version_option(__version__, prog_name=CLI_NAME)
@click.option("--json", "json_mode", is_flag=True, default=False,
              envvar="CLI_ANYTHING_JSON", help="machine-readable JSON output.")
@click.option("--dry-run", is_flag=True, default=False,
              help="do not persist the session or submit documents.")
@click.pass_context
def cli(ctx: click.Context, json_mode: bool, dry_run: bool) -> None:
    """cli-anything harness for Gaosi WMS (gaosirobot-wms-app).

    Use --json for agent-readable output. Mutating commands auto-save the
    session unless --dry-run is given.
    """
    ctx.obj = Runtime(json_mode, dry_run)


def build_or_fail(rt: Runtime, build_fn, *args):
    """Run a payload builder; turn draft-shape ValueErrors into clean failures."""
    try:
        return build_fn(*args)
    except ValueError as exc:
        fail(str(exc), json_mode=rt.json_mode)


# ---------------------------------------------------------------------------
# server
# ---------------------------------------------------------------------------


@cli.group()
def server() -> None:
    """Server environment management (production / test / custom)."""


@server.command("show")
@click.pass_obj
def server_show(rt: Runtime) -> None:
    """Show the current server configuration."""
    cfg = dict(rt.session.server)
    cfg["base_url"] = rt.session.base_url
    presets = SERVER_PRESETS
    cfg["presets"] = presets
    rt.emit(cfg)


@server.command("use")
@click.argument("environment", type=click.Choice(["production", "test", "custom"]))
@click.option("--url", help="base URL for the custom environment.")
@click.pass_obj
def server_use(rt: Runtime, environment: str, url: str | None) -> None:
    """Switch server environment (clears login state, like the GUI)."""
    if environment == "custom":
        if not url:
            fail("--url is required for the custom environment", json_mode=rt.json_mode)
        base = rt.session.use_custom(url)
    else:
        base = rt.session.use_preset(environment)
    rt.session.clear_auth()  # app clears login state on server switch
    rt.save()
    rt.emit({"environment": environment, "base_url": base},
            notice="login state cleared on server switch")


@server.command("probe")
@click.option("--url", help="probe an arbitrary base URL instead of the current one.")
@click.pass_obj
def server_probe(rt: Runtime, url: str | None) -> None:
    """Check server connectivity (mirrors the GUI's save-time probe)."""
    import requests as _requests

    base = (url or rt.session.base_url).rstrip("/")
    try:
        resp = _requests.get(base + "/", timeout=5)
        ok = resp.status_code < 500
        detail = f"HTTP {resp.status_code}"
    except _requests.RequestException as exc:
        ok, detail = False, str(exc)
    rt.emit({"base_url": base, "reachable": ok, "detail": detail})


# ---------------------------------------------------------------------------
# auth
# ---------------------------------------------------------------------------


@cli.group("auth")
def authgrp() -> None:
    """Authentication (login / logout / whoami)."""


@authgrp.command("login")
@click.option("-u", "--username", prompt=True)
@click.option("-p", "--password", envvar="WMS_PASSWORD", default=None,
              prompt=True, hide_input=True)
@click.pass_obj
def auth_login(rt: Runtime, username: str, password: str) -> None:
    """Log in and persist the token (POST /MobileLogin)."""
    client = rt.client()
    try:
        token = auth.login(client, username, password)
    except WmsTransportError as exc:
        fail(f"network failure: {exc}", json_mode=rt.json_mode)
    except WmsError as exc:
        fail(f"login failed ({exc.code}): {exc.msg}", code=exc.code,
             json_mode=rt.json_mode)
    rt.session.token = token
    # fetch user snapshot for document creator fields (best-effort)
    try:
        authed = WmsClient(rt.session.base_url, token)
        info = auth.get_user_info(authed)
        rt.session.user = info.get("user") if isinstance(info, dict) else None
        rt.set_client_meta(authed)
    except WmsError:
        pass
    rt.save()
    rt.emit({"username": username, "token": token},
            notice=rt._client_msg or "login ok")


@authgrp.command("logout")
@click.pass_obj
def auth_logout(rt: Runtime) -> None:
    """Log out; clears token and user snapshot."""
    if rt.session.is_logged_in:
        client = rt.client()
        try:
            auth.logout(client)
            rt.set_client_meta(client)
        except (WmsError, WmsTransportError):
            rt.notice("logout request failed; clearing local state anyway")
    rt.session.clear_auth()
    rt.save()
    rt.emit({"logged_in": False})


@authgrp.command("status")
@click.pass_obj
def auth_status(rt: Runtime) -> None:
    """Show login state and token summary."""
    tok = rt.session.token
    summary: dict = {"logged_in": rt.session.is_logged_in}
    if isinstance(tok, dict):
        summary["mode"] = "double"
        summary["expires_in"] = {"access": tok.get("accessExpiresIn"),
                                 "refresh": tok.get("refreshExpiresIn")}
    elif isinstance(tok, str) and tok:
        summary["mode"] = "single"
        summary["token_prefix"] = tok[:8] + "..."
    summary["user"] = rt.session.user
    rt.emit(summary)


@authgrp.command("whoami")
@click.pass_obj
def auth_whoami(rt: Runtime) -> None:
    """Fetch /getInfo from the server."""
    rt.emit(api_call(rt, auth.get_user_info))


# ---------------------------------------------------------------------------
# purchasing
# ---------------------------------------------------------------------------


@cli.group()
def purchasing() -> None:
    """Purchasing: delivery notes, package scans, bins, arrival, inbound."""


@purchasing.command("delivery")
@click.argument("c_code")
@click.pass_obj
def purchasing_delivery(rt: Runtime, c_code: str) -> None:
    """Look up an SRM delivery note (GetDeliveryDoc)."""
    rt.emit(api_call(rt, get_delivery_note, c_code))


@purchasing.command("package")
@click.argument("pack_code")
@click.pass_obj
def purchasing_package(rt: Runtime, pack_code: str) -> None:
    """Scan a package for receiving (GetPackageMin)."""
    rt.emit(api_call(rt, get_package_min, pack_code))


@purchasing.command("package-max")
@click.argument("package_id")
@click.pass_obj
def purchasing_package_max(rt: Runtime, package_id: str) -> None:
    """List small packages under a max package (GetPackageMax)."""
    rt.emit(api_call(rt, get_package_max, package_id))


@purchasing.command("bin")
@click.argument("c_pos_code")
@click.pass_obj
def purchasing_bin(rt: Runtime, c_pos_code: str) -> None:
    """Look up one bin (GetPosition)."""
    rt.emit(api_call(rt, get_bin, c_pos_code))


@purchasing.command("bins")
@click.argument("c_pos_name")
@click.pass_obj
def purchasing_bins(rt: Runtime, c_pos_name: str) -> None:
    """Search bins by name (GetPositionList)."""
    rt.emit(api_call(rt, list_bins, c_pos_name))


@purchasing.command("arrival-submit")
@click.option("--data", help="GRN payload as JSON text.")
@click.option("--file", type=click.File("r", encoding="utf-8"),
              help="GRN payload as a JSON file ('-' = stdin).")
@click.pass_obj
def purchasing_arrival_submit(rt: Runtime, data: str | None, file) -> None:
    """Submit an arrival voucher (AddArrivalVouch) from a JSON payload."""
    grn = load_json_argument(data, file)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": grn})
        return
    rt.emit(api_call(rt, submit_arrival, grn))


# -- inbound draft flow (CGRK) --


@purchasing.command("inbound-scan")
@click.argument("pack_code")
@click.option("--pos", help="target bin code (cPosCode) stored with the draft item.")
@click.pass_obj
def purchasing_inbound_scan(rt: Runtime, pack_code: str, pos: str | None) -> None:
    """Scan a package into the inbound draft (GetPackageMin_CGRK)."""
    item = api_call(rt, inbound_scan, pack_code, pos)
    if pos:
        item = dict(item)
        item["cPosCode"] = pos
    idx = rt.session.draft_add("inbound", item)
    rt.save()  # auto-save after one-shot mutation
    rt.emit({"draft_index": idx, "item": item})


@purchasing.command("inbound-list")
@click.pass_obj
def purchasing_inbound_list(rt: Runtime) -> None:
    """Show the inbound draft."""
    rt.emit(rt.session.draft("inbound"))


@purchasing.command("inbound-remove")
@click.argument("index", type=int)
@click.pass_obj
def purchasing_inbound_remove(rt: Runtime, index: int) -> None:
    """Remove one draft item by index."""
    try:
        item = rt.session.draft_remove("inbound", index)
    except IndexError:
        fail(f"draft index {index} out of range", json_mode=rt.json_mode)
    rt.save()
    rt.emit({"removed": item})


@purchasing.command("inbound-submit")
@click.option("--date", "d_date", default=today, show_default="today",
              help="document date (YYYY-MM-DD).")
@click.option("--pos", default=None, help="default bin for items without one.")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def purchasing_inbound_submit(rt: Runtime, d_date: str, pos: str | None,
                              user_code: str | None, user_name: str | None) -> None:
    """Submit the inbound draft as a document (AddCGRK)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_inbound_request,
                            rt.session.draft("inbound"), d_date, code, name, pos)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_inbound, payload))
    rt.session.draft_clear("inbound")
    rt.save()


@purchasing.command("inbound-clear")
@click.pass_obj
def purchasing_inbound_clear(rt: Runtime) -> None:
    """Clear the inbound draft."""
    n = rt.session.draft_clear("inbound")
    rt.save()
    rt.emit({"cleared": n})


# ---------------------------------------------------------------------------
# transfers
# ---------------------------------------------------------------------------


@cli.group()
def transfer() -> None:
    """Transfers: production (AddDBDMom) and warehouse (AddDBD) flows."""


@transfer.command("warehouses")
@click.pass_obj
def transfer_warehouses(rt: Runtime) -> None:
    """List warehouses (GetWareHouseList)."""
    data = api_call(rt, list_warehouses)
    rt.emit(data.get("datas") if isinstance(data, dict) else data)


@transfer.command("mo")
@click.argument("mo_code")
@click.pass_obj
def transfer_mo(rt: Runtime, mo_code: str) -> None:
    """Look up a production order (GetMomOrderDetail)."""
    rt.emit(api_call(rt, get_mo_detail, mo_code))


@transfer.command("scan")
@click.argument("pack_code")
@click.option("--pos-in", help="target bin stored with the draft item.")
@click.pass_obj
def transfer_scan(rt: Runtime, pack_code: str, pos_in: str | None) -> None:
    """Scan a package into the production-transfer draft (ScanDBDPackCode)."""
    item = api_call(rt, scan_pack, pack_code, rt.session.draft_popcodes("transfer"))
    if pos_in:
        item = dict(item)
        item["cPosCodeIn"] = pos_in
    idx = rt.session.draft_add("transfer", item)
    rt.save()
    rt.emit({"draft_index": idx, "item": item})


@transfer.command("scan-back")
@click.argument("pack_code")
@click.option("--pos", required=True, help="bin used when the package was scanned.")
@click.pass_obj
def transfer_scan_back(rt: Runtime, pack_code: str, pos: str) -> None:
    """Undo one scan (ScanDBDPackCodeBack)."""
    rt.emit(api_call(rt, scan_pack_back, pack_code, pos))


@transfer.command("submit")
@click.argument("mo_code")
@click.option("--wh-out", required=True)
@click.option("--wh-in", required=True)
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--pos-in", default=None, help="default target bin.")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def transfer_submit(rt: Runtime, mo_code: str, wh_out: str, wh_in: str,
                    d_date: str, pos_in: str | None,
                    user_code: str | None, user_name: str | None) -> None:
    """Submit the production-transfer draft (AddDBDMom)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_transfer_request,
                            rt.session.draft("transfer"), mo_code, wh_out,
                            wh_in, d_date, code, name, pos_in)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_transfer, payload))
    rt.session.draft_clear("transfer")
    rt.save()


@transfer.command("scan2")
@click.argument("pack_code")
@click.option("--wh-out", required=True)
@click.option("--wh-in", required=True)
@click.option("--pos-in", required=True)
@click.pass_obj
def transfer_scan2(rt: Runtime, pack_code: str, wh_out: str, wh_in: str,
                   pos_in: str) -> None:
    """Scan a package for a warehouse transfer (ScanDBDPackCode2)."""
    item = api_call(rt, scan_warehouse_pack, pack_code,
                    rt.session.draft_popcodes("warehouse"), wh_out, wh_in, pos_in)
    item = dict(item)
    item["cPosCodeIn"] = pos_in
    idx = rt.session.draft_add("warehouse", item)
    rt.save()
    rt.emit({"draft_index": idx, "item": item})


@transfer.command("submit-warehouse")
@click.option("--wh-out", required=True)
@click.option("--wh-in", required=True)
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--pos-in", default=None, help="default target bin.")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def transfer_submit_warehouse(rt: Runtime, wh_out: str, wh_in: str, d_date: str,
                              pos_in: str | None, user_code: str | None,
                              user_name: str | None) -> None:
    """Submit the warehouse-transfer draft (AddDBD)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_warehouse_request,
                            rt.session.draft("warehouse"), wh_out, wh_in,
                            d_date, code, name, pos_in)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_warehouse_transfer, payload))
    rt.session.draft_clear("warehouse")
    rt.save()


@transfer.command("list")
@click.argument("group", type=click.Choice(["transfer", "warehouse"]))
@click.pass_obj
def transfer_list(rt: Runtime, group: str) -> None:
    """Show a transfer draft."""
    rt.emit(rt.session.draft(group))


# ---------------------------------------------------------------------------
# finished goods
# ---------------------------------------------------------------------------


@cli.group()
def finished() -> None:
    """Finished-goods inbound (成品入库, AddCCPRK)."""


@finished.command("position")
@click.pass_obj
def finished_position(rt: Runtime) -> None:
    """Get the recommended bin (GetPosition_CCPRK)."""
    rt.emit(api_call(rt, get_recommended_position))


@finished.command("material")
@click.argument("bar_code_under")
@click.option("--pos", help="target bin stored with the draft item.")
@click.pass_obj
def finished_material(rt: Runtime, bar_code_under: str, pos: str | None) -> None:
    """Scan a finished-goods barcode into the draft (GetMaterial_CCPRK)."""
    item = api_call(rt, get_material, bar_code_under)
    if pos:
        item = dict(item)
        item["cPosCode"] = pos
    idx = rt.session.draft_add("finished", item)
    rt.save()
    rt.emit({"draft_index": idx, "item": item})


@finished.command("submit")
@click.option("--wh", required=True, help="warehouse code (cWhCode).")
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--pos", default=None, help="default bin for items without one.")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def finished_submit(rt: Runtime, wh: str, d_date: str, pos: str | None,
                    user_code: str | None, user_name: str | None) -> None:
    """Submit the finished-goods draft (AddCCPRK)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_finished_request,
                            rt.session.draft("finished"), wh, d_date,
                            code, name, pos)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_finished, payload))
    rt.session.draft_clear("finished")
    rt.save()


@finished.command("list")
@click.pass_obj
def finished_list(rt: Runtime) -> None:
    """Show the finished-goods draft."""
    rt.emit(rt.session.draft("finished"))


# ---------------------------------------------------------------------------
# sales
# ---------------------------------------------------------------------------


@cli.group()
def sales() -> None:
    """Shipping plans and sales outbound."""


@sales.command("plans")
@click.option("--code", default=None)
@click.option("--begin-date", default=None)
@click.option("--end-date", default=None)
@click.pass_obj
def sales_plans(rt: Runtime, code: str | None, begin_date: str | None,
                end_date: str | None) -> None:
    """List shipping plans (GetU9CShipPlanList)."""
    data = api_call(rt, list_shipping_plans, code, begin_date, end_date)
    rt.emit(data.get("datas") if isinstance(data, dict) else data)


@sales.command("plan-submit")
@click.argument("ship_plan_code")
@click.pass_obj
def sales_plan_submit(rt: Runtime, ship_plan_code: str) -> None:
    """Generate a sales-outbound doc from a shipping plan (AddXSCK)."""
    rt.emit(api_call(rt, submit_shipping_plan, ship_plan_code))


@sales.command("outbounds")
@click.option("--code", default=None)
@click.option("--begin-date", default=None)
@click.option("--end-date", default=None)
@click.pass_obj
def sales_outbounds(rt: Runtime, code: str | None, begin_date: str | None,
                    end_date: str | None) -> None:
    """List sales-outbound documents (GetWmsXSCKList)."""
    data = api_call(rt, list_outbounds, code, begin_date, end_date)
    rt.emit(data.get("datas") if isinstance(data, dict) else data)


@sales.command("outbound-confirm")
@click.argument("c_code")
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def sales_outbound_confirm(rt: Runtime, c_code: str, d_date: str,
                           user_code: str | None, user_name: str | None) -> None:
    """Confirm a sales-outbound document (ConfirmXSCK)."""
    code, name = creator_args(rt, user_code, user_name)
    rt.emit(api_call(rt, confirm_outbound, c_code, d_date, code, name))


# ---------------------------------------------------------------------------
# returns / trace / messages
# ---------------------------------------------------------------------------


@cli.group()
def returns() -> None:
    """Purchase return (AddCGTH) and reject (AddCGJS) flows."""


@returns.command("reject-scan")
@click.argument("pack_code")
@click.pass_obj
def returns_reject_scan(rt: Runtime, pack_code: str) -> None:
    """Scan a package into the reject draft (GetPackageMin_CGJS)."""
    item = api_call(rt, reject_scan, pack_code)
    idx = rt.session.draft_add("reject", item)
    rt.save()
    rt.emit({"draft_index": idx, "item": item})


@returns.command("reject-submit")
@click.option("--reason", required=True, help="reject reason (cReason).")
@click.option("--memo", default="", help="memo (cMemo).")
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def returns_reject_submit(rt: Runtime, reason: str, memo: str, d_date: str,
                          user_code: str | None, user_name: str | None) -> None:
    """Submit the reject draft (AddCGJS)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_reject_request,
                            rt.session.draft("reject"), d_date, reason,
                            memo, code, name)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_reject, payload))
    rt.session.draft_clear("reject")
    rt.save()


@returns.command("return-scan")
@click.argument("pack_code")
@click.pass_obj
def returns_return_scan(rt: Runtime, pack_code: str) -> None:
    """Scan a package into the return draft (GetPackageMin_CGTH)."""
    item = api_call(rt, return_scan, pack_code)
    idx = rt.session.draft_add("return", item)
    rt.save()
    rt.emit({"draft_index": idx, "item": item})


@returns.command("return-submit")
@click.option("--reason", required=True)
@click.option("--memo", default="")
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def returns_return_submit(rt: Runtime, reason: str, memo: str, d_date: str,
                          user_code: str | None, user_name: str | None) -> None:
    """Submit the return draft (AddCGTH)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_return_request,
                            rt.session.draft("return"), d_date, reason,
                            memo, code, name)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_return, payload))
    rt.session.draft_clear("return")
    rt.save()


@returns.command("list")
@click.argument("group", type=click.Choice(["reject", "return"]))
@click.pass_obj
def returns_list(rt: Runtime, group: str) -> None:
    """Show a reject/return draft."""
    rt.emit(rt.session.draft(group))


@cli.command("trace")
@click.argument("pack_code")
@click.pass_obj
def trace(rt: Runtime, pack_code: str) -> None:
    """Package traceability query (GetPackageMinStaus)."""
    rt.emit(api_call(rt, package_status, pack_code))


@cli.group()
def messages() -> None:
    """System messages (SysUserMsg)."""


@messages.command("list")
@click.option("--all", "show_all", is_flag=True, help="include read messages.")
@click.option("--types", "msg_types", default=None, help="filter by msgType.")
@click.pass_obj
def messages_list(rt: Runtime, show_all: bool, msg_types: str | None) -> None:
    """List system messages (unread by default)."""
    data = api_call(rt, list_messages, None if show_all else False, msg_types)
    rt.emit(data.get("result") if isinstance(data, dict) else data)


@messages.command("read")
@click.argument("msg_id")
@click.argument("msg_type")
@click.pass_obj
def messages_read(rt: Runtime, msg_id: str, msg_type: str) -> None:
    """Mark a message read (POST /SysUserMsg/read/{id}/{type})."""
    rt.emit(api_call(rt, read_message, msg_id, msg_type))


# ---------------------------------------------------------------------------
# web admin — list / detail / sync / AGV / master / system
# ---------------------------------------------------------------------------


@cli.group("web")
def webgrp() -> None:
    """Web admin operations (gaosirobot-wms-web): lists, details, U9C sync, AGV, master data."""


@webgrp.group("auth")
def webauth() -> None:
    """Web admin authentication (POST /login with MD5 + tenantId)."""


@webauth.command("login")
@click.option("-u", "--username", prompt=True)
@click.option("-p", "--password", envvar="WMS_PASSWORD", default=None,
              prompt=True, hide_input=True)
@click.option("--tenant-id", default="tenant0", show_default="tenant0",
              help="tenant ID (tenantId header).")
@click.pass_obj
def web_auth_login(rt: Runtime, username: str, password: str, tenant_id: str) -> None:
    """Log in via web admin endpoint and persist the token."""
    wc = rt.web_client()
    try:
        token = web_login(wc, username, password, tenant_id)
    except WmsAuthError as exc:
        fail(f"authentication expired (401): {exc.msg}; run `web auth login`",
             code=401, json_mode=rt.json_mode)
    except WmsTransportError as exc:
        fail(f"network failure: {exc}", json_mode=rt.json_mode)
    except WmsError as exc:
        fail(f"API error {exc.code}: {exc.msg}", code=exc.code, data=exc.data,
             json_mode=rt.json_mode)
    rt.session.token = token
    rt._client_msg = "web login ok"
    # Fetch user info
    wc2 = WebWmsClient(rt.session.base_url, token, tenant_id=tenant_id)
    try:
        info = web_get_info(wc2)
    except Exception:
        info = {}
    rt.session._data.setdefault("web", {}).update({
        "tenant_id": tenant_id,
        "user_name": username,
        "user_id": info.get("userId", 0) if isinstance(info, dict) else 0,
    })
    if isinstance(info, dict):
        rt.session.user = info
    rt.save()
    rt.emit({"logged_in": True, "username": username, "tenant_id": tenant_id},
            notice=rt._client_msg or "web login ok")


@webauth.command("logout")
@click.pass_obj
def web_auth_logout(rt: Runtime) -> None:
    """Log out from the web admin session."""
    wc = rt.web_client()
    try:
        web_logout(wc)
    except Exception:
        pass  # best-effort
    rt.session.clear_auth()
    rt.session._data.pop("web", None)
    rt.save()
    rt.emit({"logged_in": False})


@webauth.command("whoami")
@click.pass_obj
def web_auth_whoami(rt: Runtime) -> None:
    """Fetch /getInfo from the server."""
    wc = rt.web_client()
    try:
        info = web_get_info(wc)
    except WmsError as exc:
        fail(f"API error {exc.code}: {exc.msg}", code=exc.code, json_mode=rt.json_mode)
    rt.emit(info)


@webauth.command("status")
@click.pass_obj
def web_auth_status(rt: Runtime) -> None:
    """Show web admin login state."""
    wdata = rt.session._data.get("web", {})
    summary = {
        "logged_in": rt.session.is_logged_in,
        "tenant_id": wdata.get("tenant_id", "tenant0"),
        "user_name": wdata.get("user_name", ""),
        "user_id": wdata.get("user_id", 0),
        "token_prefix": (str(rt.session.token)[:12] + "...") if rt.session.token else None,
    }
    rt.emit(summary)


# -- generic list / detail helper --


def _web_list(rt: Runtime, list_fn, query: dict, data_key: str = "datas") -> None:
    """Common pattern: call a list function, unwrap paginated datas."""
    raw = web_api_call(rt, list_fn, **query)
    if isinstance(raw, dict) and data_key in raw:
        rt.emit(raw[data_key])
    else:
        rt.emit(raw)


def _web_detail(rt: Runtime, detail_fn, c_code: str) -> None:
    rt.emit(web_api_call(rt, detail_fn, c_code))


def _parse_query(pairs: tuple[str, ...]) -> dict:
    """Parse -q values into a dict.

    Accepts repeatable ``k=v`` items, combined ``k=v&k2=v2`` strings, and a
    single JSON object (``{"k": v}``). Empty keys or values are dropped.
    """
    q: dict[str, Any] = {}
    for item in pairs:
        text = item.strip()
        if not text:
            continue
        if text.startswith("{"):
            try:
                obj = json.loads(text)
            except json.JSONDecodeError:
                obj = None
            if isinstance(obj, dict):
                q.update({k: v for k, v in obj.items()
                          if k and v not in (None, "")})
                continue
        for part in text.split("&"):
            k, _, v = part.partition("=")
            if k and v:
                q[k] = v
    return q


# -- purchasing web commands --


@webgrp.group("purchasing")
def webpurchasing() -> None:
    """Web purchasing: GRN, inbound, rejection, return lists + detail + sync + delete."""


@webpurchasing.command("grn-list")
@click.option("-q", "--query", multiple=True, help="filter k=v (repeatable).")
@click.pass_obj
def web_purchasing_grn_list(rt: Runtime, query: tuple[str, ...]) -> None:
    """List arrival vouchers (到货单列表)."""
    _web_list(rt, list_grn, _parse_query(query))


@webpurchasing.command("grn-detail")
@click.argument("c_code")
@click.pass_obj
def web_purchasing_grn_detail(rt: Runtime, c_code: str) -> None:
    """Arrival voucher detail."""
    _web_detail(rt, get_grn_detail, c_code)


@webpurchasing.command("grn-inspect")
@click.argument("c_codes")
@click.pass_obj
def web_purchasing_grn_inspect(rt: Runtime, c_codes: str) -> None:
    """Mark arrival vouchers as inspected."""
    rt.emit(web_api_call(rt, post_srm_inspect, c_codes))


@webpurchasing.command("grn-delete")
@click.argument("c_codes")
@click.pass_obj
def web_purchasing_grn_delete(rt: Runtime, c_codes: str) -> None:
    """Delete arrival vouchers (comma-separated codes)."""
    rt.emit(web_api_call(rt, delete_grn, c_codes))


@webpurchasing.command("inbound-list")
@click.option("-q", "--query", multiple=True, help="filter k=v (repeatable).")
@click.pass_obj
def web_purchasing_inbound_list(rt: Runtime, query: tuple[str, ...]) -> None:
    """List purchase inbound orders (采购入库单)."""
    _web_list(rt, list_purchase_inbound, _parse_query(query))


@webpurchasing.command("inbound-detail")
@click.argument("c_code")
@click.pass_obj
def web_purchasing_inbound_detail(rt: Runtime, c_code: str) -> None:
    """Purchase inbound detail."""
    _web_detail(rt, get_purchase_inbound_detail, c_code)


@webpurchasing.command("inbound-delete")
@click.argument("c_codes")
@click.pass_obj
def web_purchasing_inbound_delete(rt: Runtime, c_codes: str) -> None:
    """Delete purchase inbound orders."""
    rt.emit(web_api_call(rt, delete_purchase_inbound, c_codes))


@webpurchasing.command("inbound-sync")
@click.argument("c_codes")
@click.pass_obj
def web_purchasing_inbound_sync(rt: Runtime, c_codes: str) -> None:
    """Sync purchase inbound to U9C ERP."""
    rt.emit(web_api_call(rt, upload_cgrk_u9c, c_codes))


@webpurchasing.command("rejection-list")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_purchasing_rejection_list(rt: Runtime, query: tuple[str, ...]) -> None:
    """List purchase rejection orders (采购拒收单)."""
    _web_list(rt, list_purchase_rejection, _parse_query(query))


@webpurchasing.command("rejection-detail")
@click.argument("c_code")
@click.pass_obj
def web_purchasing_rejection_detail(rt: Runtime, c_code: str) -> None:
    """Purchase rejection detail."""
    _web_detail(rt, get_purchase_rejection_detail, c_code)


@webpurchasing.command("rejection-all")
@click.argument("c_code")
@click.pass_obj
def web_purchasing_rejection_all(rt: Runtime, c_code: str) -> None:
    """Purchase rejection summary (for print)."""
    rt.emit(web_api_call(rt, get_purchase_rejection_all, c_code))


@webpurchasing.command("rejection-delete")
@click.argument("c_codes")
@click.pass_obj
def web_purchasing_rejection_delete(rt: Runtime, c_codes: str) -> None:
    """Delete purchase rejection orders."""
    rt.emit(web_api_call(rt, delete_purchase_rejection, c_codes))


@webpurchasing.command("return-list")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_purchasing_return_list(rt: Runtime, query: tuple[str, ...]) -> None:
    """List purchase return orders (采购退货单)."""
    _web_list(rt, list_purchase_return, _parse_query(query))


@webpurchasing.command("return-detail")
@click.argument("c_code")
@click.pass_obj
def web_purchasing_return_detail(rt: Runtime, c_code: str) -> None:
    """Purchase return detail."""
    _web_detail(rt, get_purchase_return_detail, c_code)


@webpurchasing.command("return-all")
@click.argument("c_code")
@click.pass_obj
def web_purchasing_return_all(rt: Runtime, c_code: str) -> None:
    """Purchase return summary (for print)."""
    rt.emit(web_api_call(rt, get_purchase_return_all, c_code))


@webpurchasing.command("return-delete")
@click.argument("c_codes")
@click.pass_obj
def web_purchasing_return_delete(rt: Runtime, c_codes: str) -> None:
    """Delete purchase return orders."""
    rt.emit(web_api_call(rt, delete_purchase_return, c_codes))


@webpurchasing.command("return-sync")
@click.argument("c_codes")
@click.pass_obj
def web_purchasing_return_sync(rt: Runtime, c_codes: str) -> None:
    """Sync purchase return to U9C ERP."""
    rt.emit(web_api_call(rt, upload_purchase_return_u9c, c_codes))


# -- sales web commands --


@webgrp.group("sales")
def websales() -> None:
    """Web sales: outbound lists, detail, U9C sync, AGV notification."""


@websales.command("list")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_sales_list(rt: Runtime, query: tuple[str, ...]) -> None:
    """List sales outbound orders (销售出库单)."""
    _web_list(rt, list_sales_outbound, _parse_query(query))


@websales.command("detail")
@click.argument("c_code")
@click.pass_obj
def web_sales_detail(rt: Runtime, c_code: str) -> None:
    """Sales outbound detail."""
    _web_detail(rt, get_sales_outbound_detail, c_code)


@websales.command("sync")
@click.argument("c_codes")
@click.pass_obj
def web_sales_sync(rt: Runtime, c_codes: str) -> None:
    """Sync sales outbound to U9C ERP."""
    rt.emit(web_api_call(rt, upload_xsck_u9c, c_codes))


@websales.command("agv")
@click.argument("c_code")
@click.pass_obj
def web_sales_agv(rt: Runtime, c_code: str) -> None:
    """Notify AGV for sales outbound."""
    rt.emit(web_api_call(rt, post_xsck_agv, c_code))


# -- manufacturing web commands --


@webgrp.group("manufacturing")
def webmfg() -> None:
    """Web manufacturing: order lists and details."""


@webmfg.command("list")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_mfg_list(rt: Runtime, query: tuple[str, ...]) -> None:
    """List manufacturing orders (生产工单)."""
    _web_list(rt, list_manufacturing_order, _parse_query(query))


@webmfg.command("detail")
@click.argument("mo_code")
@click.pass_obj
def web_mfg_detail(rt: Runtime, mo_code: str) -> None:
    """Manufacturing order detail."""
    rt.emit(web_api_call(rt, get_manufacturing_order_detail, mo_code))


# -- transfer web commands --


@webgrp.group("transfer")
def webtransfer() -> None:
    """Web transfers: production and non-production lists, detail, U9C sync."""


@webtransfer.command("list")
@click.option("-q", "--query", multiple=True)
@click.option("--type", "transfer_type",
              type=click.Choice(["production", "nonproduction", "all"]),
              default="all", help="filter by transfer type.")
@click.pass_obj
def web_transfer_list(rt: Runtime, query: tuple[str, ...], transfer_type: str) -> None:
    """List transfer orders."""
    q = _parse_query(query)
    if transfer_type == "production":
        _web_list(rt, list_transfer_order, q)
    elif transfer_type == "nonproduction":
        _web_list(rt, list_nonproduction_transfer, q)
    else:
        prod = web_api_call(rt, list_transfer_order, **q)
        nonprod = web_api_call(rt, list_nonproduction_transfer, **q)
        rt.emit({"production": prod, "nonproduction": nonprod})


@webtransfer.command("detail")
@click.argument("c_code")
@click.option("--type", "transfer_type",
              type=click.Choice(["production", "nonproduction"]),
              default="production")
@click.pass_obj
def web_transfer_detail(rt: Runtime, c_code: str, transfer_type: str) -> None:
    """Transfer detail."""
    fn = get_transfer_order_detail if transfer_type == "production" else get_nonproduction_transfer_detail
    _web_detail(rt, fn, c_code)


@webtransfer.command("sync")
@click.argument("c_codes")
@click.option("--type", "transfer_type",
              type=click.Choice(["production", "nonproduction"]),
              default="production")
@click.pass_obj
def web_transfer_sync(rt: Runtime, c_codes: str, transfer_type: str) -> None:
    """Sync transfer to U9C ERP."""
    fn = upload_transfer_u9c if transfer_type == "production" else upload_nonproduction_transfer_u9c
    rt.emit(web_api_call(rt, fn, c_codes))


# -- finished goods web commands --


@webgrp.group("finished")
def webfinished() -> None:
    """Web finished goods: inbound lists, detail, U9C sync, AGV."""


@webfinished.command("list")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_finished_list(rt: Runtime, query: tuple[str, ...]) -> None:
    """List finished-goods inbound orders (产成品入库)."""
    _web_list(rt, list_finished_inbound, _parse_query(query))


@webfinished.command("detail")
@click.argument("c_code")
@click.pass_obj
def web_finished_detail(rt: Runtime, c_code: str) -> None:
    """Finished-goods inbound detail."""
    _web_detail(rt, get_finished_inbound_detail, c_code)


@webfinished.command("delete")
@click.argument("c_codes")
@click.pass_obj
def web_finished_delete(rt: Runtime, c_codes: str) -> None:
    """Delete finished-goods inbound orders."""
    rt.emit(web_api_call(rt, delete_finished_inbound, c_codes))


@webfinished.command("sync")
@click.argument("c_codes")
@click.pass_obj
def web_finished_sync(rt: Runtime, c_codes: str) -> None:
    """Sync finished-goods inbound to U9C ERP."""
    rt.emit(web_api_call(rt, upload_ccprk_u9c, c_codes))


@webfinished.command("agv")
@click.argument("c_code")
@click.pass_obj
def web_finished_agv(rt: Runtime, c_code: str) -> None:
    """Notify AGV for finished-goods inbound."""
    rt.emit(web_api_call(rt, post_ccprk_agv, c_code))


# -- completion web commands --


@webgrp.group("completion")
def webcompletion() -> None:
    """Web production completion: list + U9C sync."""


@webcompletion.command("list")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_completion_list(rt: Runtime, query: tuple[str, ...]) -> None:
    """List completion declarations (完工申报)."""
    _web_list(rt, list_completion, _parse_query(query))


@webcompletion.command("sync")
@click.argument("bar_codes")
@click.pass_obj
def web_completion_sync(rt: Runtime, bar_codes: str) -> None:
    """Sync completion declarations to U9C ERP."""
    rt.emit(web_api_call(rt, upload_completion_u9c, bar_codes))


# -- reports web commands --


@webgrp.group("report")
def webreport() -> None:
    """Web reports: inventory detail and summary."""


@webreport.command("inventory")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_report_inventory(rt: Runtime, query: tuple[str, ...]) -> None:
    """Inventory report — detail (库存报表)."""
    _web_list(rt, list_inventory_report, _parse_query(query))


@webreport.command("summary")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_report_summary(rt: Runtime, query: tuple[str, ...]) -> None:
    """Inventory report — summary (库存汇总)."""
    _web_list(rt, list_inventory_report_sum, _parse_query(query))


# -- master data web commands --


@webgrp.group("master")
def webmaster() -> None:
    """Web master data: warehouses, materials, suppliers, bins."""


@webmaster.command("warehouses")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_master_warehouses(rt: Runtime, query: tuple[str, ...]) -> None:
    """List warehouses (仓库列表)."""
    _web_list(rt, list_warehouse, _parse_query(query))


@webmaster.command("materials")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_master_materials(rt: Runtime, query: tuple[str, ...]) -> None:
    """List materials (物料列表)."""
    _web_list(rt, list_material, _parse_query(query))


@webmaster.command("suppliers")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_master_suppliers(rt: Runtime, query: tuple[str, ...]) -> None:
    """List suppliers (供应商列表)."""
    _web_list(rt, list_supplier, _parse_query(query))


@webmaster.command("bins")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_master_bins(rt: Runtime, query: tuple[str, ...]) -> None:
    """List bins/positions (货位列表)."""
    _web_list(rt, list_bin, _parse_query(query))


@webmaster.command("bin-tree")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_master_bin_tree(rt: Runtime, query: tuple[str, ...]) -> None:
    """Warehouse → zone → bin tree."""
    rt.emit(web_api_call(rt, get_position_tree, **_parse_query(query)))


# -- system management web commands --


@webgrp.group("system")
def webservice() -> None:
    """Web system management: users, roles, dict, config."""


@webservice.command("users")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_system_users(rt: Runtime, query: tuple[str, ...]) -> None:
    """List system users."""
    _web_list(rt, list_user, _parse_query(query))


@webservice.command("roles")
@click.option("-q", "--query", multiple=True)
@click.pass_obj
def web_system_roles(rt: Runtime, query: tuple[str, ...]) -> None:
    """List roles."""
    _web_list(rt, list_role, _parse_query(query))


@webservice.command("dict")
@click.argument("dict_type")
@click.pass_obj
def web_system_dict(rt: Runtime, dict_type: str) -> None:
    """List dictionary data by type."""
    rt.emit(web_api_call(rt, list_dict_data, dict_type))


@webservice.command("config")
@click.argument("config_key")
@click.pass_obj
def web_system_config(rt: Runtime, config_key: str) -> None:
    """Get system config by key."""
    rt.emit(web_api_call(rt, get_config, config_key))


# -- raw escape hatch + drafts + repl
# ---------------------------------------------------------------------------


@cli.command("request", context_settings={"ignore_unknown_options": True})
@click.argument("method", type=click.Choice(["GET", "POST", "PUT", "DELETE"]))
@click.argument("path")
@click.option("--data", default=None, help="JSON request body.")
@click.option("-q", "--query", multiple=True, help="query param k=v (repeatable).")
@click.pass_obj
def request(rt: Runtime, method: str, path: str, data: str | None,
            query: tuple[str, ...]) -> None:
    """Raw API escape hatch: request GET /MyClass/MyApi/GetPackageMin -q PackCode=X."""
    params = _parse_query(query)
    payload = json.loads(data) if data else None
    rt.emit(api_call(rt, lambda cl: cl.request(method, path, payload, params)))


@cli.group("draft")
def draftgrp() -> None:
    """Draft (scan cart) management across workflows."""


@draftgrp.command("show")
@click.argument("group", type=click.Choice(DRAFT_GROUPS), required=False)
@click.pass_obj
def draft_show(rt: Runtime, group: str | None) -> None:
    """Show one draft or all drafts."""
    if group:
        rt.emit(rt.session.draft(group))
        return
    rt.emit({g: rt.session.draft(g) for g in DRAFT_GROUPS})


@draftgrp.command("clear")
@click.argument("group", type=click.Choice(DRAFT_GROUPS))
@click.pass_obj
def draft_clear(rt: Runtime, group: str) -> None:
    """Clear one draft."""
    n = rt.session.draft_clear(group)
    rt.save()
    rt.emit({"cleared": n})


@cli.command("status")
@click.pass_obj
def status(rt: Runtime) -> None:
    """Session summary: server, login, draft counts."""
    if rt.json_mode:
        snap = rt.session.snapshot()
        rt.emit({"server": snap.get("server"),
                 "logged_in": rt.session.is_logged_in,
                 "user": rt.session.user,
                 "draft_counts": {g: len(rt.session.draft(g)) for g in DRAFT_GROUPS}})
    else:
        click.echo(rt.session.summary())


def _repl_once(rt: Runtime, line: str) -> None:
    """Execute one REPL line through the same Click command tree."""
    args = shlex.split(line)
    if not args:
        return
    if args[0] in ("exit", "quit"):
        raise SystemExit(0)
    if args[0] == "--json":
        rt.json_mode = True
        args = args[1:] or ["--help"]
    try:
        cli.main(args=args, prog_name=CLI_NAME, standalone_mode=False)
    except SystemExit as exc:  # click uses SystemExit for usage errors
        if exc.code not in (0, None):
            click.echo(f"usage error (exit {exc.code})", err=True)
    except click.ClickException as exc:
        exc.show()
    except (WmsError, WmsTransportError) as exc:
        click.echo(f"API failure: {exc}", err=True)
    except ValueError as exc:
        click.echo(f"error: {exc}", err=True)


@cli.command()
@click.pass_obj
def repl(rt: Runtime) -> None:
    """Interactive REPL mode (also entered when invoked with no arguments)."""
    banner = (f"{CLI_NAME} {__version__} — interactive mode\n"
              f"server: {rt.session.base_url}  logged in: {rt.session.is_logged_in}\n"
              "type 'help' for commands, 'exit' to quit")
    click.echo(banner)
    while True:
        try:
            line = click.prompt(click.style("wms>", fg="cyan"), prompt_suffix=" ")
        except (EOFError, KeyboardInterrupt):
            click.echo()
            return
        try:
            _repl_once(rt, line)
        except SystemExit:
            return


def main() -> None:
    """Console entry point: REPL when invoked with no arguments on a TTY."""
    if not sys.argv[1:] and sys.stdin.isatty():
        cli.main(args=["repl"], prog_name=CLI_NAME)
        return
    cli(auto_envvar_prefix="WMS")


if __name__ == "__main__":
    main()
