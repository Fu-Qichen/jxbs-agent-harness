"""cli_anything.gaosirobot_wms — CLI harness for the Gaosi WMS (gaosirobot-wms-app) backend."""

__version__ = "1.1.2"
SOFTWARE = "gaosirobot-wms"
CLI_NAME = "cli-anything-gaosirobot-wms"
