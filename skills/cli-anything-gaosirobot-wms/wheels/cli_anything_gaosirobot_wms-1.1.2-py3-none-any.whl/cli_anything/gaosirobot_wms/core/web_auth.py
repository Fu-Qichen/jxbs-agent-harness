"""Web admin authentication — mirrors src/store/modules/user.js login flow.

The web admin uses a different login endpoint and auth mechanism than the PDA:

- Login: ``POST /login`` with ``{username, password (MD5), code, uuid, clientId, tenantId}``
- Header: ``userName: <username>``
- Response: ``{code, data: "<token>", msg}``
- Subsequent requests: ``Authorization: Bearer <token>``, ``tenantId``, ``userid``, ``userName``

Password is MD5-hashed client-side (``crypto-js/md5``) before sending.
"""

from __future__ import annotations

import hashlib
from typing import Any

from cli_anything.gaosirobot_wms.core.client import WmsAuthError, WmsClient, WmsError


def md5_hash(text: str) -> str:
    """MD5 hash matching the web admin's ``crypto-js/md5`` behavior."""
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def web_login(
    client: WmsClient,
    username: str,
    password: str,
    tenant_id: str = "tenant0",
    code: str = "",
    uuid: str = "",
    client_id: str = "",
) -> str:
    """Log in via the web admin endpoint and return the token string.

    Mirrors ``src/api/system/login.js`` + ``src/store/modules/user.js``.
    """
    md5_pw = md5_hash(password)
    payload = {
        "username": username,
        "password": md5_pw,
        "code": code,
        "uuid": uuid,
        "clientId": client_id,
        "tenantId": tenant_id,
    }
    data = client.post("/login", data=payload)
    token = WmsClient.extract_token(data)
    if isinstance(token, dict):
        raise WmsError(-1, "web login returned a token object, expected string", token)
    return token


def web_get_info(client: WmsClient) -> dict[str, Any]:
    """Fetch user info from ``GET /getInfo`` (web admin pattern)."""
    return client.get("/getInfo") or {}


def web_logout(client: WmsClient) -> None:
    """Log out via ``POST /logout``."""
    try:
        client.post("/logout")
    except WmsError:
        pass  # best-effort; session cleared locally regardless
