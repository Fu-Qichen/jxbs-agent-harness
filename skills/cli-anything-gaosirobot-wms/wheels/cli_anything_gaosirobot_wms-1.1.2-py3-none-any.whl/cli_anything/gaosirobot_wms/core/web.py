"""Web admin API functions — one function per GUI action.

Maps every ``src/api/*.js`` export to a Python callable that takes a
``WebWmsClient`` and returns the unwrapped ``data`` payload.
"""

from __future__ import annotations

from typing import Any

from cli_anything.gaosirobot_wms.core.web_client import WebWmsClient


def _get(client: WebWmsClient, url: str, **params: Any) -> Any:
    """GET with params, dropping None values."""
    return client.get(url, params={k: v for k, v in params.items() if v is not None})


def _post_params(client: WebWmsClient, url: str, **params: Any) -> Any:
    """POST with params (not body), matching the web admin's ``params: data`` pattern."""
    return client.post(url, params={k: v for k, v in params.items() if v is not None})


# ── Purchasing ────────────────────────────────────────────────────────────

def list_grn(client: WebWmsClient, **query: Any) -> Any:
    """List arrival vouchers (到货单列表)."""
    return _get(client, "/MyClass/MyMethod/GetWmsArrivalVouch", **query)


def get_grn_detail(client: WebWmsClient, c_code: str) -> Any:
    """Arrival voucher detail."""
    return _get(client, "/MyClass/MyMethod/GetWmsArrivalVouchs", cCode=c_code)


def post_srm_inspect(client: WebWmsClient, c_codes: str) -> Any:
    """Mark arrival vouchers as inspected (到货单报检)."""
    return _post_params(client, "/MyClass/MyMethod/PostSrmInspect", cCodes=c_codes)


def delete_grn(client: WebWmsClient, c_codes: str) -> Any:
    """Delete arrival vouchers."""
    return _post_params(client, "/MyClass/MyMethod/DelWmsArrivalVouch", cCodes=c_codes)


def list_purchase_inbound(client: WebWmsClient, **query: Any) -> Any:
    """List purchase inbound orders (采购入库单列表)."""
    return _get(client, "/MyClass/MyMethod/GetCGRKList", **query)


def get_purchase_inbound_detail(client: WebWmsClient, c_code: str) -> Any:
    """Purchase inbound detail."""
    return _get(client, "/MyClass/MyMethod/GetCGRKDetail", cCode=c_code)


def delete_purchase_inbound(client: WebWmsClient, c_codes: str) -> Any:
    """Delete purchase inbound orders."""
    return _post_params(client, "/MyClass/MyMethod/DelCGRK", cCodes=c_codes)


def upload_cgrk_u9c(client: WebWmsClient, c_codes: str) -> Any:
    """Sync purchase inbound to U9C ERP."""
    return _post_params(client, "/MyClass/MyMethod/UploadCGRKU9C", cCodes=c_codes)


def list_purchase_rejection(client: WebWmsClient, **query: Any) -> Any:
    """List purchase rejection orders (采购拒收单列表)."""
    return _get(client, "/MyClass/MyMethod/GetWmsCGJS", **query)


def get_purchase_rejection_detail(client: WebWmsClient, c_code: str) -> Any:
    """Purchase rejection detail."""
    return _get(client, "/MyClass/MyMethod/GetWmsCGJSS", cCode=c_code)


def get_purchase_rejection_all(client: WebWmsClient, c_code: str) -> Any:
    """Purchase rejection summary (for print)."""
    return _get(client, "/MyClass/MyMethod/GetWmsCGJSSAll", cCode=c_code)


def delete_purchase_rejection(client: WebWmsClient, c_codes: str) -> Any:
    """Delete purchase rejection orders."""
    return _post_params(client, "/MyClass/MyMethod/DelWmsCGJS", cCodes=c_codes)


def list_purchase_return(client: WebWmsClient, **query: Any) -> Any:
    """List purchase return orders (采购退货单列表)."""
    return _get(client, "/MyClass/MyMethod/GetCGTHList", **query)


def get_purchase_return_detail(client: WebWmsClient, c_code: str) -> Any:
    """Purchase return detail."""
    return _get(client, "/MyClass/MyMethod/GetCGTHDetail", cCode=c_code)


def get_purchase_return_all(client: WebWmsClient, c_code: str) -> Any:
    """Purchase return summary (for print)."""
    return _get(client, "/MyClass/MyMethod/GetCGTHAll", cCode=c_code)


def delete_purchase_return(client: WebWmsClient, c_codes: str) -> Any:
    """Delete purchase return orders."""
    return _post_params(client, "/MyClass/MyMethod/DelCGTH", cCodes=c_codes)


def upload_purchase_return_u9c(client: WebWmsClient, c_codes: str) -> Any:
    """Sync purchase return to U9C ERP."""
    return _post_params(client, "/MyClass/MyMethod/UploadCGTHU9C", cCodes=c_codes)


# ── Sales ─────────────────────────────────────────────────────────────────

def list_sales_outbound(client: WebWmsClient, **query: Any) -> Any:
    """List sales outbound orders (销售出库单列表)."""
    return _get(client, "/MyClass/MyMethod/GetXSCKList", **query)


def get_sales_outbound_detail(client: WebWmsClient, c_code: str) -> Any:
    """Sales outbound detail."""
    return _get(client, "/MyClass/MyMethod/GetXSCKDetail", cCode=c_code)


def upload_xsck_u9c(client: WebWmsClient, c_codes: str) -> Any:
    """Sync sales outbound to U9C ERP."""
    return _post_params(client, "/MyClass/MyMethod/UploadXSCKU9C", cCodes=c_codes)


def post_xsck_agv(client: WebWmsClient, c_code: str) -> Any:
    """Notify AGV for sales outbound."""
    return _post_params(client, "/MyClass/MyMethod/PostXSCKAgv", cCode=c_code)


# ── Manufacturing ─────────────────────────────────────────────────────────

def list_manufacturing_order(client: WebWmsClient, **query: Any) -> Any:
    """List manufacturing orders (生产工单列表)."""
    return _get(client, "/MyClass/MyMethod/GetMomOrder", **query)


def get_manufacturing_order_detail(client: WebWmsClient, mo_code: str) -> Any:
    """Manufacturing order detail."""
    return _get(client, "/MyClass/MyMethod/GetMomOrderDetail", moCode=mo_code)


def list_transfer_order(client: WebWmsClient, **query: Any) -> Any:
    """List production transfer orders (生产调拨单列表)."""
    return _get(client, "/MyClass/MyMethod/GetDBDList", **query)


def get_transfer_order_detail(client: WebWmsClient, c_code: str) -> Any:
    """Production transfer detail."""
    return _get(client, "/MyClass/MyMethod/GetDBDDetail", cCode=c_code)


def upload_transfer_u9c(client: WebWmsClient, c_codes: str) -> Any:
    """Sync production transfer to U9C ERP."""
    return _post_params(client, "/MyClass/MyMethod/UploadDBDU9C", cCodes=c_codes)


# ── Non-production Transfer ───────────────────────────────────────────────

def list_nonproduction_transfer(client: WebWmsClient, **query: Any) -> Any:
    """List non-production transfer orders (非生产调拨单列表)."""
    return _get(client, "/MyClass/MyMethod/GetDBDList2", **query)


def get_nonproduction_transfer_detail(client: WebWmsClient, c_code: str) -> Any:
    """Non-production transfer detail."""
    return _get(client, "/MyClass/MyMethod/GetDBDDetail2", cCode=c_code)


def upload_nonproduction_transfer_u9c(client: WebWmsClient, c_codes: str) -> Any:
    """Sync non-production transfer to U9C ERP."""
    return _post_params(client, "/MyClass/MyMethod/UploadDBD2U9C", cCodes=c_codes)


# ── Finished Goods ────────────────────────────────────────────────────────

def list_finished_inbound(client: WebWmsClient, **query: Any) -> Any:
    """List finished-goods inbound orders (产成品入库单列表)."""
    return _get(client, "/MyClass/MyMethod/GetCCPRKList", **query)


def get_finished_inbound_detail(client: WebWmsClient, c_code: str) -> Any:
    """Finished-goods inbound detail."""
    return _get(client, "/MyClass/MyMethod/GetCCPRKDetail", cCode=c_code)


def delete_finished_inbound(client: WebWmsClient, c_codes: str) -> Any:
    """Delete finished-goods inbound orders."""
    return _post_params(client, "/MyClass/MyMethod/DelCGRK", cCodes=c_codes)


def upload_ccprk_u9c(client: WebWmsClient, c_codes: str) -> Any:
    """Sync finished-goods inbound to U9C ERP."""
    return _post_params(client, "/MyClass/MyMethod/UploadCCPRKU9C", cCodes=c_codes)


def post_ccprk_agv(client: WebWmsClient, c_code: str) -> Any:
    """Notify AGV for finished-goods inbound."""
    return _post_params(client, "/MyClass/MyMethod/PostCCPRKAgv", cCode=c_code)


# ── Production Completion ─────────────────────────────────────────────────

def list_completion(client: WebWmsClient, **query: Any) -> Any:
    """List completion declarations (完工申报列表)."""
    return _get(client, "/MyClass/MyMethod/GetWmsCompleteApplyList", **query)


def upload_completion_u9c(client: WebWmsClient, bar_codes: str) -> Any:
    """Sync completion declarations to U9C ERP."""
    return _post_params(client, "/MyClass/MyMethod/UploadCompleteApplyU9C", barCodes=bar_codes)


# ── Reports ───────────────────────────────────────────────────────────────

def list_inventory_report(client: WebWmsClient, **query: Any) -> Any:
    """Inventory report (库存报表 — detail)."""
    return _get(client, "/MyClass/MyMethod/GetWmsCurrentStock", **query)


def list_inventory_report_sum(client: WebWmsClient, **query: Any) -> Any:
    """Inventory report (库存报表 — summary)."""
    return _get(client, "/MyClass/MyMethod/GetWmsCurrentStockSum", **query)


# ── Master Data ───────────────────────────────────────────────────────────

def list_warehouse(client: WebWmsClient, **query: Any) -> Any:
    """List warehouses (仓库列表)."""
    return _get(client, "/MyClass/MyMethod/GetWareHouseList", **query)


def list_material(client: WebWmsClient, **query: Any) -> Any:
    """List materials (物料列表)."""
    return _get(client, "/MyClass/MyMethod/GetInventoryList", **query)


def list_supplier(client: WebWmsClient, **query: Any) -> Any:
    """List suppliers (供应商列表)."""
    return _get(client, "/MyClass/MyMethod/GetSupplierList", **query)


def list_bin(client: WebWmsClient, **query: Any) -> Any:
    """List bins/positions (货位列表)."""
    return _get(client, "/MyClass/MyMethod/GetPositionList", **query)


def get_bin(client: WebWmsClient, c_pos_code: str) -> Any:
    """Get one bin by code."""
    return _get(client, "/MyClass/MyMethod/GetPosition", cPosCode=c_pos_code)


def add_bin(client: WebWmsClient, data: dict) -> Any:
    """Add a new bin/position."""
    return client.post("/MyClass/MyMethod/AddPosition", data=data)


def update_bin(client: WebWmsClient, data: dict) -> Any:
    """Update a bin/position."""
    return client.post("/MyClass/MyMethod/UpdatePosition", data=data)


def delete_bin(client: WebWmsClient, c_pos_codes: str) -> Any:
    """Delete bins (comma-separated codes)."""
    return client.post("/MyClass/MyMethod/DeletePosition",
                       data={"cPosCode": c_pos_codes})


def get_position_tree(client: WebWmsClient, **query: Any) -> Any:
    """Warehouse → zone → bin tree."""
    return _get(client, "/MyClass/MyMethod/GetPositionTreeList", **query)


# ── Warehouse Transfer (web admin listing) ────────────────────────────────

def list_warehouse_transfer(client: WebWmsClient, **query: Any) -> Any:
    """List warehouse transfer orders via the web admin endpoint."""
    return _get(client, "/MyClass/MyMethod/GetDBDList2", **query)


# ── System Management (RuoYi-style) ──────────────────────────────────────

def list_user(client: WebWmsClient, **query: Any) -> Any:
    """List system users."""
    return _get(client, "/system/user/list", **query)


def get_user(client: WebWmsClient, user_id: int) -> Any:
    """Get user detail."""
    return _get(client, f"/system/user/{user_id}")


def list_role(client: WebWmsClient, **query: Any) -> Any:
    """List roles."""
    return _get(client, "/system/role/list", **query)


def list_dict_data(client: WebWmsClient, dict_type: str) -> Any:
    """List dictionary data by type."""
    return _get(client, f"/system/dict/data/type/{dict_type}")


def get_config(client: WebWmsClient, config_key: str) -> Any:
    """Get system config by key."""
    return _get(client, f"/system/config/configKey/{config_key}")


# ── Common ────────────────────────────────────────────────────────────────

def get_delivery_note(client: WebWmsClient, c_code: str) -> Any:
    """Look up SRM delivery note (采购收料 — shared with PDA)."""
    return _get(client, "/MyClass/MyApi/GetDeliveryDoc", cCode=c_code)


def get_package_min(client: WebWmsClient, pack_code: str) -> Any:
    """Scan a package (shared with PDA)."""
    return _get(client, "/MyClass/MyApi/GetPackageMin", PackCode=pack_code)


def package_status(client: WebWmsClient, pack_code: str) -> Any:
    """Package traceability query (shared with PDA)."""
    return _get(client, "/MyClass/MyApi/GetPackageMinStaus", PackCode=pack_code)
