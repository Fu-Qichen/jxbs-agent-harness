"""Extended WMS client for web admin requests.

Adds the extra headers the web admin axios interceptor sends on every request
(``tenantId``, ``userid``, ``userName``) — the PDA client does not carry these.
"""

from __future__ import annotations

from typing import Any

from cli_anything.gaosirobot_wms.core.client import WmsClient


class WebWmsClient(WmsClient):
    """WmsClient augmented with web admin headers."""

    def __init__(
        self,
        base_url: str,
        token: str | dict | None = None,
        timeout: float = 60.0,
        tenant_id: str = "tenant0",
        user_id: int = 0,
        user_name: str = "",
    ) -> None:
        super().__init__(base_url, token, timeout)
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.user_name = user_name

    def request(
        self,
        method: str,
        path: str,
        data: Any = None,
        params: dict | None = None,
        headers: dict | None = None,
        timeout: float | None = None,
    ) -> Any:
        web_headers: dict[str, str] = {
            "tenantId": self.tenant_id,
        }
        if self.user_id:
            web_headers["userid"] = str(self.user_id)
        if self.user_name:
            from urllib.parse import quote
            web_headers["userName"] = quote(self.user_name)
        if headers:
            web_headers.update(headers)
        return super().request(method, path, data=data, params=params,
                               headers=web_headers, timeout=timeout)

    def describe(self) -> dict:
        info = super().describe()
        info["tenant_id"] = self.tenant_id
        info["user_id"] = self.user_id
        info["user_name"] = self.user_name
        return info
