"""Unit tests for core modules — synthetic data, no external services.

The HTTP layer is exercised through monkeypatched ``requests.request`` so the
envelope contract of ``src/http/http.ts`` is verified directly.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from cli_anything.gaosirobot_wms.core import purchasing, finished, returns, transfer
from cli_anything.gaosirobot_wms.core.client import (
    WmsAuthError,
    WmsClient,
    WmsError,
)
from cli_anything.gaosirobot_wms.core.session import Session


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


class FakeResponse:
    def __init__(self, status_code: int, body) -> None:
        self.status_code = status_code
        self._body = body
        self.url = "http://fake"

    def json(self):
        if self._body is None:
            raise ValueError("no json")
        return self._body


def patch_transport(monkeypatch, status_code=200, body=None, capture=None):
    """Replace requests.request; optionally capture the outgoing request."""

    def fake_request(method, url, **kwargs):
        if capture is not None:
            capture.append({"method": method, "url": url, **kwargs})
        return FakeResponse(status_code, body)

    monkeypatch.setattr("cli_anything.gaosirobot_wms.core.client.requests.request",
                        fake_request)


PKG = {
    "cInvCode": "100101A1", "cInvName": "法兰盘", "packCode": "PKG001",
    "packCodeMax": "MAX01", "poNo": "PO001", "poRowId": "9", "cBatch": "B001",
    "qualifiedQuantity": 10, "autoIdSrm": "S1", "cInvStd": "DN50",
    "cComUnitName": "个", "cVenCode": "V001", "cVenName": "供应商一",
    "cWhCode": "WH01",
}


# ---------------------------------------------------------------------------
# A. client / envelope
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("code", [0, 200])
def test_client_success_codes(monkeypatch, code):
    patch_transport(monkeypatch, 200, {"code": code, "msg": "ok", "data": {"x": 1}})
    client = WmsClient("http://fake")
    assert client.get("/x") == {"x": 1}
    assert client.last_code == code


def test_client_confirm_code_250(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 250, "msg": "确认提交?", "data": [1, 2]})
    client = WmsClient("http://fake")
    assert client.get("/x") == [1, 2]
    assert client.last_code == 250
    assert client.last_msg == "确认提交?"


def test_client_business_error(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 400, "msg": "库存不足", "data": None})
    with pytest.raises(WmsError) as ei:
        WmsClient("http://fake").get("/x")
    assert ei.value.code == 400
    assert "库存不足" in ei.value.msg


@pytest.mark.parametrize("status,code", [(200, 401), (401, 200), (401, 401)])
def test_client_unauthorized(monkeypatch, status, code):
    patch_transport(monkeypatch, status, {"code": code, "msg": "过期", "data": None})
    with pytest.raises(WmsAuthError):
        WmsClient("http://fake").get("/x")


def test_client_http_error(monkeypatch):
    patch_transport(monkeypatch, 500, {"code": 500, "msg": "boom"})
    with pytest.raises(WmsError) as ei:
        WmsClient("http://fake").get("/x")
    assert ei.value.code == 500


def test_client_non_json_body(monkeypatch):
    patch_transport(monkeypatch, 200, "plain text")
    assert WmsClient("http://fake").get("/x") == "plain text"


def test_message_fallback_to_message_field(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 400, "message": "envelope msg key"})
    with pytest.raises(WmsError) as ei:
        WmsClient("http://fake").get("/x")
    assert ei.value.msg == "envelope msg key"


# ---------------------------------------------------------------------------
# A. token handling
# ---------------------------------------------------------------------------


def test_token_extraction():
    assert WmsClient.extract_token("TOKEN123") == "TOKEN123"
    double = {"accessToken": "A", "refreshToken": "R", "accessExpiresIn": 1,
              "refreshExpiresIn": 2}
    assert WmsClient.extract_token(double) == double
    with pytest.raises(WmsError):
        WmsClient.extract_token("")
    with pytest.raises(WmsError):
        WmsClient.extract_token({"nope": 1})


def test_bearer_header(monkeypatch):
    capture: list = []
    patch_transport(monkeypatch, 200, {"code": 0, "data": None}, capture)
    client = WmsClient("http://fake", token="TOKEN123")
    client.get("/x", {"q": "1"})
    assert capture[0]["headers"]["Authorization"] == "Bearer TOKEN123"


def test_double_token_bearer(monkeypatch):
    capture: list = []
    patch_transport(monkeypatch, 200, {"code": 0, "data": None}, capture)
    tok = {"accessToken": "A1", "refreshToken": "R1"}
    client = WmsClient("http://fake", token=tok)
    client.get("/x")
    assert capture[0]["headers"]["Authorization"] == "Bearer A1"
    assert client.refresh_token == "R1"

# ---------------------------------------------------------------------------
# A. session
# ---------------------------------------------------------------------------


def test_session_roundtrip(tmp_path: Path):
    path = tmp_path / "session.json"
    s1 = Session(path=path)
    s1.use_custom("10.0.0.9:30001")
    s1.token = "T"
    s1.draft_add("inbound", {"packCode": "P1"})
    s1.save()
    s2 = Session(path=path)
    assert s2.base_url == "http://10.0.0.9:30001"
    assert s2.is_logged_in
    assert s2.draft("inbound") == [{"packCode": "P1"}]


def test_session_server_presets(tmp_path: Path):
    s = Session(path=tmp_path / "s.json")
    assert s.use_preset("production") == "http://211.91.60.61:30001"
    assert s.use_preset("test") == "http://211.91.60.61:20001"
    with pytest.raises(ValueError):
        s.use_preset("staging")
    # custom without scheme is normalized, trailing slash stripped
    assert s.use_custom("https://host.example/") == "https://host.example"


def test_draft_operations(tmp_path: Path):
    s = Session(path=tmp_path / "s.json")
    i1 = s.draft_add("transfer", {"packCode": "A"})
    s.draft_add("transfer", {"packCode": "B"})
    s.draft_add("inbound", {"packCode": "C"})
    assert s.draft_popcodes("transfer") == ["A", "B"]
    removed = s.draft_remove("transfer", i1)
    assert removed["packCode"] == "A"
    assert s.draft_clear("transfer") == 1
    assert s.draft_clear("transfer") == 0
    with pytest.raises(ValueError):
        s.draft("nope")


def test_clear_auth(tmp_path: Path):
    s = Session(path=tmp_path / "s.json")
    s.token = {"accessToken": "A", "refreshToken": "R"}
    s.user = {"userName": "admin"}
    s.clear_auth()
    assert not s.is_logged_in and s.user is None


# ---------------------------------------------------------------------------
# A. payload builders
# ---------------------------------------------------------------------------


def test_build_inbound_request():
    payload = purchasing.build_inbound_request(
        [dict(PKG, cPosCode="POS1")], "2026-09-07", "admin", "Administrator")
    assert payload["dDate"] == "2026-09-07"
    assert payload["cVenCode"] == "V001"
    assert payload["cWhCode"] == "WH01"
    row = payload["datas"][0]
    assert row["cInvCode"] == "100101A1"
    assert row["iQuantity"] == "10"  # qualifiedQuantity stringified
    assert row["cPosCode"] == "POS1"


def test_build_inbound_requires_pos():
    with pytest.raises(ValueError):
        purchasing.build_inbound_request([], "2026-09-07", "a", "b")
    with pytest.raises(ValueError):
        purchasing.build_inbound_request([dict(PKG)], "2026-09-07", "a", "b",
                                         default_pos=None)


def test_build_reject_request_capital_datas():
    item = {"arrivalVouchsAutoId": 7, "arrivalVouchCode": "ARR1", "cCodeSRM": "SRM1",
            "cInvCode": "M1", "cInvName": "n", "cInvStd": "s", "cComUnitName": "u",
            "poNo": "PO", "poRowId": "1", "packCode": "P", "packCodeMax": "M",
            "cBatch": "B", "iQuantity": 5, "cVenCode": "V", "cVenName": "供应商"}
    payload = returns.build_reject_request([item], "2026-09-07", "质量", "memo",
                                           "admin", "Admin")
    assert "Datas" in payload and "datas" not in payload
    assert payload["Datas"][0]["arrivalVouchCode"] == "ARR1"
    assert payload["cVenCode"] == "V"


def test_build_transfer_request():
    item = {"cInvCode": "M", "cInvName": "n", "cInvStd": "s", "cComUnitName": "u",
            "packCode": "P", "packCodeMax": "PM", "cPosCode": "OUT1", "cBatch": "B",
            "iQuantity": 3, "cPosCodeIn": "IN1"}
    payload = transfer.build_transfer_request([item], "MO-0023", "WH1", "WH2",
                                              "2026-09-07", "admin", "Admin")
    assert payload["moCode"] == "MO-0023"
    row = payload["datas"][0]
    assert row["cPosCodeOut"] == "OUT1" and row["cPosCodeIn"] == "IN1"
    assert row["iQuantity"] == "3"
    with pytest.raises(ValueError):
        transfer.build_transfer_request([], "MO", "W1", "W2", "d", "a", "b")


def test_build_finished_request():
    item = {"cInvCode": "FG1", "cInvName": "成品", "cInvStd": "S", "cComUnitName": "件",
            "iQuantity": 2, "moCode": "MO-1", "moDId": "D1", "barCode": "BC",
            "barCodeUnder": "BCU", "cPosCode": "P1"}
    payload = finished.build_inbound_request([item], "WH9", "2026-09-07",
                                             "admin", "Admin")
    row = payload["datas"][0]
    assert payload["cWhCode"] == "WH9"
    assert row["barCodeUnder"] == "BCU"
    assert row["moDId"] == "D1"
    assert row["cBatch"] == "MO-1"  # GUI derives batch from the MO code


def test_build_return_request():
    item = {"packCode": "P1", "iQuantity": 4}
    payload = returns.build_return_request([item], "2026-09-07", "r", "m",
                                           "admin", "Admin")
    assert payload["datas"] == [{"packCode": "P1", "iQuantity": "4"}]


def test_inbound_json_roundtrip():
    payload = purchasing.build_inbound_request([dict(PKG, cPosCode="POS1")],
                                               "2026-09-07", "admin", "Admin")
    assert json.loads(json.dumps(payload)) == payload  # serializable


# ---------------------------------------------------------------------------
# B. web client / auth
# ---------------------------------------------------------------------------

from cli_anything.gaosirobot_wms.core.web_client import WebWmsClient
from cli_anything.gaosirobot_wms.core.web_auth import md5_hash, web_login, web_get_info
from cli_anything.gaosirobot_wms.core import web


def test_web_client_adds_tenant_header(monkeypatch):
    capture: list = []
    patch_transport(monkeypatch, 200, {"code": 0, "data": None}, capture)
    wc = WebWmsClient("http://fake", token="T", tenant_id="tenant1", user_id=42, user_name="admin")
    wc.get("/x")
    hdrs = capture[0]["headers"]
    assert hdrs["tenantId"] == "tenant1"
    assert hdrs["userid"] == "42"
    assert hdrs["userName"] == "admin"
    assert hdrs["Authorization"] == "Bearer T"


def test_web_client_describe():
    wc = WebWmsClient("http://fake", token="T", tenant_id="t1", user_id=1, user_name="u")
    d = wc.describe()
    assert d["tenant_id"] == "t1"
    assert d["user_id"] == 1
    assert d["user_name"] == "u"


def test_md5_hash():
    # Must match crypto-js/md5 output
    assert md5_hash("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5_hash("password") == "5f4dcc3b5aa765d61d8327deb882cf99"


def test_web_login_sends_md5_password(monkeypatch):
    capture: list = []
    patch_transport(monkeypatch, 200, {"code": 0, "data": "WEB_TOKEN", "msg": "ok"}, capture)
    wc = WebWmsClient("http://fake")
    token = web_login(wc, "admin", "password", tenant_id="tenant1")
    assert token == "WEB_TOKEN"
    body = capture[0]["json"]
    assert body["password"] == "5f4dcc3b5aa765d61d8327deb882cf99"  # MD5 of "password"
    assert body["tenantId"] == "tenant1"


def test_web_login_rejects_object_token(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 0, "data": {"accessToken": "X"}})
    wc = WebWmsClient("http://fake")
    with pytest.raises(WmsError):
        web_login(wc, "u", "p")


# ---------------------------------------------------------------------------
# B. web API functions (mock transport)
# ---------------------------------------------------------------------------


def test_web_list_grn(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 0, "data": {"datas": [{"cCode": "A"}], "page": {}}})
    wc = WebWmsClient("http://fake", token="T")
    result = web.list_grn(wc, pageNum=1, pageSize=10)
    assert result["datas"][0]["cCode"] == "A"


def test_web_get_grn_detail(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 0, "data": {"cCode": "A", "datas": []}})
    wc = WebWmsClient("http://fake", token="T")
    result = web.get_grn_detail(wc, "A")
    assert result["cCode"] == "A"


def test_web_upload_cgrk_u9c(monkeypatch):
    capture: list = []
    patch_transport(monkeypatch, 200, {"code": 0, "data": "ok"}, capture)
    wc = WebWmsClient("http://fake", token="T")
    web.upload_cgrk_u9c(wc, "GRK001,GRK002")
    assert capture[0]["params"]["cCodes"] == "GRK001,GRK002"


def test_web_post_xsck_agv(monkeypatch):
    capture: list = []
    patch_transport(monkeypatch, 200, {"code": 0, "data": "ok"}, capture)
    wc = WebWmsClient("http://fake", token="T")
    web.post_xsck_agv(wc, "XSCK001")
    assert capture[0]["params"]["cCode"] == "XSCK001"


def test_web_list_warehouse(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 0, "data": [{"cWhCode": "WH1"}]})
    wc = WebWmsClient("http://fake", token="T")
    result = web.list_warehouse(wc)
    assert result[0]["cWhCode"] == "WH1"


def test_web_list_material(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 0, "data": {"datas": [{"cInvCode": "M1"}]}})
    wc = WebWmsClient("http://fake", token="T")
    result = web.list_material(wc, pageNum=1)
    assert result["datas"][0]["cInvCode"] == "M1"


def test_web_list_inventory_report(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 0, "data": {"datas": [], "page": {"totalNum": 0}}})
    wc = WebWmsClient("http://fake", token="T")
    result = web.list_inventory_report(wc, cWhCode="WH1")
    assert "page" in result


def test_web_dict_data(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 0, "data": [{"dictLabel": "男", "dictValue": "0"}]})
    wc = WebWmsClient("http://fake", token="T")
    result = web.list_dict_data(wc, "sys_user_sex")
    assert result[0]["dictValue"] == "0"


# ---------------------------------------------------------------------------
# B. web CLI commands (Click CliRunner)
# ---------------------------------------------------------------------------

from click.testing import CliRunner
from cli_anything.gaosirobot_wms.gaosirobot_wms_cli import cli


def _run(*args, env=None):
    import os
    runner = CliRunner()
    env = {**(env or {}), "CLI_ANYTHING_JSON": "1", "WMS_PASSWORD": "test"}
    return runner.invoke(cli, list(args), env=env)


def test_web_help():
    r = _run("web", "--help")
    assert r.exit_code == 0
    assert "purchasing" in r.output
    assert "sales" in r.output
    assert "master" in r.output


def test_web_auth_status_no_login():
    import tempfile, os
    with tempfile.TemporaryDirectory() as td:
        session_file = os.path.join(td, "session.json")
        r = _run("web", "auth", "status", env={"CLI_ANYTHING_WMS_SESSION": session_file})
        assert r.exit_code == 0
        data = json.loads(r.output)
        assert data["ok"] is True
        assert data["data"]["logged_in"] is False


def test_web_purchasing_help():
    r = _run("web", "purchasing", "--help")
    assert r.exit_code == 0
    assert "grn-list" in r.output
    assert "inbound-sync" in r.output


def test_web_sales_help():
    r = _run("web", "sales", "--help")
    assert r.exit_code == 0
    assert "list" in r.output
    assert "sync" in r.output
    assert "agv" in r.output


def test_web_master_help():
    r = _run("web", "master", "--help")
    assert r.exit_code == 0
    assert "warehouses" in r.output
    assert "materials" in r.output
    assert "suppliers" in r.output
    assert "bins" in r.output


def test_web_transfer_help():
    r = _run("web", "transfer", "--help")
    assert r.exit_code == 0
    assert "production" in r.output
    assert "sync" in r.output
    # Check list command for --type option
    r2 = _run("web", "transfer", "list", "--help")
    assert "nonproduction" in r2.output
