"""Purchasing domain — src/api/purchasing.ts (+ purchase-return.ts).

Covers: delivery notes (SRM), package scans, bins, arrival voucher, and
purchase inbound (CGRK) with draft accumulation.
"""

from __future__ import annotations

from typing import Any

from cli_anything.gaosirobot_wms.core.client import WmsClient

# -- read-only queries -------------------------------------------------


def get_delivery_note(client: WmsClient, c_code: str) -> dict:
    return client.get("/MyClass/MyApi/GetDeliveryDoc", {"cCode": c_code})


def get_package_min(client: WmsClient, pack_code: str) -> dict:
    return client.get("/MyClass/MyApi/GetPackageMin", {"PackCode": pack_code})


def get_package_max(client: WmsClient, package_id: str) -> list:
    return client.get("/MyClass/MyApi/GetPackageMax", {"Id": package_id})


def get_bin(client: WmsClient, c_pos_code: str) -> dict:
    return client.get("/MyClass/MyApi/GetPosition", {"cPosCode": c_pos_code})


def list_bins(client: WmsClient, c_pos_name: str, page_size: int = 1000) -> dict:
    return client.get("/MyClass/MyMethod/GetPositionList",
                      {"cPosName": c_pos_name, "pageNum": 1, "pageSize": page_size})


# -- inbound (CGRK) ------------------------------------------------------


def inbound_scan(client: WmsClient, pack_code: str, c_pos_code: str | None = None) -> dict:
    """GET GetPackageMin_CGRK — a small package eligible for purchase inbound."""
    params: dict[str, Any] = {"PackCode": pack_code}
    if c_pos_code:
        params["cPosCode"] = c_pos_code
    return client.get("/MyClass/MyApi/GetPackageMin_CGRK", params)


def build_inbound_request(items: list[dict], d_date: str, user_code: str,
                          user_name: str, default_pos: str | None = None) -> dict:
    """Assemble an AddCGRKRequest from scanned draft items.

    Warehouse and supplier fields come from the scanned packages themselves,
    exactly like the GUI page.
    """
    if not items:
        raise ValueError("inbound draft is empty — scan at least one package")
    first = items[0]
    details = []
    for it in items:
        pos = it.get("cPosCode") or default_pos
        if not pos:
            raise ValueError(f"package {it.get('packCode')!r} has no target bin; pass --pos")
        details.append({
            "cInvCode": it.get("cInvCode", ""),
            "cInvName": it.get("cInvName", ""),
            "autoIdSrm": it.get("autoIdSrm", ""),
            "poNo": it.get("poNo", ""),
            "poRowId": it.get("poRowId", ""),
            "packCode": it.get("packCode", ""),
            "packCodeMax": it.get("packCodeMax", ""),
            "cBatch": it.get("cBatch", ""),
            "iQuantity": str(it.get("qualifiedQuantity", it.get("iQuantity", ""))),
            "cInvStd": it.get("cInvStd", ""),
            "cComUnitName": it.get("cComUnitName", ""),
            "cPosCode": pos,
        })
    return {
        "dDate": d_date,
        "cVenCode": first.get("cVenCode", ""),
        "cVenName": first.get("cVenName", ""),
        "cWhCode": first.get("cWhCode", ""),
        "createUserCode": user_code,
        "createUserName": user_name,
        "datas": details,
    }


def submit_inbound(client: WmsClient, payload: dict) -> Any:
    """POST /MyClass/MyApi/AddCGRK."""
    return client.post("/MyClass/MyApi/AddCGRK", payload)


# -- arrival voucher (GRN, 采购收料) --------------------------------------


def submit_arrival(client: WmsClient, grn: dict) -> Any:
    """POST /MyClass/MyApi/AddArrivalVouch with a full GRN payload (JSON file)."""
    return client.post("/MyClass/MyApi/AddArrivalVouch", grn)
