"""Core modules for the Gaosi WMS CLI harness."""
