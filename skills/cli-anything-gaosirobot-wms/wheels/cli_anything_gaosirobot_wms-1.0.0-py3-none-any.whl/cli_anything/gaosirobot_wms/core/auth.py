"""Authentication — mirrors src/api/login.ts + src/store/token.ts."""

from __future__ import annotations

from typing import Any

from cli_anything.gaosirobot_wms.core.client import WmsClient


def login(client: WmsClient, username: str, password: str) -> str | dict:
    """POST /MobileLogin — body {username,password}, extra ``username`` header.

    Returns the token (string in single-token mode, dict in double-token mode).
    """
    data = client.post("/MobileLogin", {"username": username, "password": password},
                       headers={"username": username})
    return client.extract_token(data)


def get_user_info(client: WmsClient) -> dict:
    """GET /getInfo — ``{user, roles, permissions}``."""
    return client.get("/getInfo")


def logout(client: WmsClient) -> Any:
    """POST /LogOut."""
    return client.post("/LogOut")


def refresh_token(client: WmsClient) -> dict:
    """POST /auth/refreshToken (double-token mode only)."""
    rt = client.refresh_token
    if not rt:
        raise ValueError("no refresh token available (single-token mode)")
    return client.post("/auth/refreshToken", {"refreshToken": rt})


def get_captcha(client: WmsClient) -> dict:
    """GET /user/getCode."""
    return client.get("/user/getCode")
