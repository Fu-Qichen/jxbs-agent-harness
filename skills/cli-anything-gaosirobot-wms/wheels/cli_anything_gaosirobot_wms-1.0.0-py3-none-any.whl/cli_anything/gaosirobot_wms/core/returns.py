"""Purchase return / reject (采购退货 / 拒收) — src/api/purchase-return.ts,
plus package trace (GetPackageMinStaus) and system messages."""

from __future__ import annotations

from typing import Any

from cli_anything.gaosirobot_wms.core.client import WmsClient


# -- purchase reject (采购拒收, AddCGJS) -----------------------------------


def reject_scan(client: WmsClient, pack_code: str) -> dict:
    return client.get("/MyClass/MyApi/GetPackageMin_CGJS", {"PackCode": pack_code})


def build_reject_request(items: list[dict], d_date: str, reason: str, memo: str,
                         user_code: str, user_name: str) -> dict:
    if not items:
        raise ValueError("reject draft is empty — scan at least one package")
    first = items[0]
    details = []
    for it in items:
        details.append({
            "cInvCode": it.get("cInvCode", ""),
            "cInvName": it.get("cInvName", ""),
            "cInvStd": it.get("cInvStd", ""),
            "cComUnitName": it.get("cComUnitName", ""),
            "arrivalVouchsAutoId": it.get("arrivalVouchsAutoId"),
            "arrivalVouchCode": it.get("arrivalVouchCode", ""),
            "cCodeSRM": it.get("cCodeSRM", ""),
            "poNo": it.get("poNo", ""),
            "poRowId": it.get("poRowId", ""),
            "packCode": it.get("packCode", ""),
            "packCodeMax": it.get("packCodeMax", ""),
            "cBatch": it.get("cBatch", ""),
            "iQuantity": it.get("iQuantity"),
        })
    return {
        "dDate": d_date,
        "cVenCode": first.get("cVenCode", ""),
        "cVenName": first.get("cVenName", ""),
        "cReason": reason,
        "cMemo": memo,
        "createUserCode": user_code,
        "createUserName": user_name,
        "Datas": details,  # capital D — backend contract
    }


def submit_reject(client: WmsClient, payload: dict) -> Any:
    return client.post("/MyClass/MyApi/AddCGJS", payload)


# -- purchase return (采购退货, AddCGTH) -----------------------------------


def return_scan(client: WmsClient, pack_code: str) -> dict:
    return client.get("/MyClass/MyApi/GetPackageMin_CGTH", {"PackCode": pack_code})


def build_return_request(items: list[dict], d_date: str, reason: str, memo: str,
                         user_code: str, user_name: str) -> dict:
    if not items:
        raise ValueError("return draft is empty — scan at least one package")
    return {
        "dDate": d_date,
        "cReason": reason,
        "cMemo": memo,
        "createUserCode": user_code,
        "createUserName": user_name,
        "datas": [{"packCode": it.get("packCode", ""),
                   "iQuantity": str(it.get("iQuantity", ""))} for it in items],
    }


def submit_return(client: WmsClient, payload: dict) -> Any:
    return client.post("/MyClass/MyApi/AddCGTH", payload)


# -- package trace (包装追溯) ----------------------------------------------


def package_status(client: WmsClient, pack_code: str) -> dict:
    """GET GetPackageMinStaus — backend endpoint name contains a typo; kept as-is."""
    return client.get("/MyClass/MyApi/GetPackageMinStaus", {"PackCode": pack_code})


# -- system messages -------------------------------------------------------


def list_messages(client: WmsClient, is_read: bool | None = None,
                  msg_types: str | None = None) -> dict:
    params: dict[str, Any] = {}
    if is_read is not None:
        params["isRead"] = is_read
    if msg_types:
        params["msgTypes"] = msg_types
    return client.get("/SysUserMsg/mylist", params)


def read_message(client: WmsClient, msg_id: str, msg_type: str) -> Any:
    return client.post(f"/SysUserMsg/read/{msg_id}/{msg_type}")
