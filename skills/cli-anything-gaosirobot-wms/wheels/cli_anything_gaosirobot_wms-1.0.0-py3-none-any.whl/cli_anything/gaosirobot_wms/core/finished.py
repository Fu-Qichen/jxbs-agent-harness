"""Finished goods inbound (成品入库) — src/api/finished-inbound-api.ts."""

from __future__ import annotations

from typing import Any

from cli_anything.gaosirobot_wms.core.client import WmsClient


def get_recommended_position(client: WmsClient) -> dict:
    """GET GetPosition_CCPRK — suggested bin for finished-goods inbound."""
    return client.get("/MyClass/MyApi/GetPosition_CCPRK")


def get_material(client: WmsClient, bar_code_under: str) -> dict:
    """GET GetMaterial_CCPRK — resolve a finished-goods barcode."""
    return client.get("/MyClass/MyApi/GetMaterial_CCPRK", {"barCodeUnder": bar_code_under})


def build_inbound_request(items: list[dict], wh_code: str, d_date: str,
                          user_code: str, user_name: str,
                          default_pos: str | None = None) -> dict:
    if not items:
        raise ValueError("finished-goods draft is empty — scan at least one barcode")
    details = []
    for it in items:
        pos = it.get("cPosCode") or default_pos
        if not pos:
            raise ValueError(f"barcode {it.get('barCodeUnder')!r} has no target bin; pass --pos")
        details.append({
            "cInvCode": it.get("cInvCode", ""),
            "cInvName": it.get("cInvName", ""),
            "cInvStd": it.get("cInvStd", ""),
            "cComUnitName": it.get("cComUnitName", ""),
            "cPosCode": pos,
            "cBatch": it.get("moCode", ""),  # GUI derives batch from the MO code
            "iQuantity": str(it.get("iQuantity", "")),
            "storageRack": it.get("storageRack", ""),
            "barCode": it.get("barCode", ""),
            "barCodeUnder": it.get("barCodeUnder", ""),
            "moDId": it.get("moDId", ""),
            "moCode": it.get("moCode", ""),
        })
    return {
        "dDate": d_date,
        "cWhCode": wh_code,
        "createUserCode": user_code,
        "createUserName": user_name,
        "datas": details,
    }


def submit_inbound(client: WmsClient, payload: dict) -> Any:
    """POST /MyClass/MyApi/AddCCPRK."""
    return client.post("/MyClass/MyApi/AddCCPRK", payload)
