"""HTTP client for the Gaosi WMS backend.

Mirrors the transport contract of the app's ``src/http/http.ts``:

- Envelope ``{code, data, msg | message}``; success codes 0 and 200.
- Business code 250 = confirm-then-proceed (GUI shows a modal and keeps the data).
- Business code 401 / HTTP 401 = expired auth (WmsAuthError).
- Single-token mode: token is a plain string; double-token mode: object with
  ``accessToken``/``refreshToken``.
- Requests carry ``Authorization: Bearer <token>`` when a token is present.
"""

from __future__ import annotations

import json
from typing import Any

import requests

SUCCESS_CODES = (0, 200)
CONFIRM_CODE = 250
UNAUTHORIZED = 401

DEFAULT_TIMEOUT = 60.0

# Runtime server presets (正式/测试), per user confirmation.
SERVER_PRESETS: dict[str, str] = {
    "production": "http://211.91.60.61:30001",
    "test": "http://211.91.60.61:20001",
}


class WmsError(Exception):
    """Base error carrying the business code and message."""

    def __init__(self, code: int, msg: str, data: Any = None) -> None:
        super().__init__(msg)
        self.code = code
        self.msg = msg
        self.data = data


class WmsAuthError(WmsError):
    """401 from the backend — the session must re-login."""


class WmsTransportError(Exception):
    """Network-level failure (DNS, refused, timeout)."""


class WmsClient:
    """Thin REST client speaking the exact envelope dialect of the app."""

    def __init__(
        self,
        base_url: str,
        token: str | dict | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout
        # Metadata of the most recent response (business code / message).
        self.last_code: int | None = None
        self.last_msg: str | None = None

    # -- auth helpers -------------------------------------------------

    @staticmethod
    def extract_token(login_data: Any) -> str | dict:
        """Login responses are the token itself: string (single) or dict (double)."""
        if isinstance(login_data, str) and login_data:
            return login_data
        if isinstance(login_data, dict) and login_data.get("accessToken"):
            return login_data
        raise WmsError(-1, "login response did not contain a token", login_data)

    @staticmethod
    def access_token_of(token: str | dict | None) -> str | None:
        """The value to place in the Authorization header."""
        if token is None:
            return None
        if isinstance(token, str):
            return token or None
        return token.get("accessToken") or None

    @property
    def refresh_token(self) -> str | None:
        if isinstance(self.token, dict):
            return self.token.get("refreshToken") or None
        return None

    # -- request core -------------------------------------------------

    def request(
        self,
        method: str,
        path: str,
        data: Any = None,
        params: dict | None = None,
        headers: dict | None = None,
        timeout: float | None = None,
    ) -> Any:
        url = path if path.startswith("http") else self.base_url + path
        hdrs: dict[str, str] = {"Content-Type": "application/json;charset=UTF-8"}
        access = self.access_token_of(self.token)
        if access:
            hdrs["Authorization"] = f"Bearer {access}"
        if headers:
            hdrs.update(headers)
        try:
            resp = requests.request(
                method.upper(),
                url,
                json=data if data is not None else None,
                params=params,
                headers=hdrs,
                timeout=timeout or self.timeout,
            )
        except requests.RequestException as exc:  # pragma: no cover - exercised via E2E
            raise WmsTransportError(f"network error talking to {url}: {exc}") from exc
        return self._handle_response(resp)

    def get(self, path: str, params: dict | None = None, **kw: Any) -> Any:
        return self.request("GET", path, params=params, **kw)

    def post(self, path: str, data: Any = None, params: dict | None = None, **kw: Any) -> Any:
        return self.request("POST", path, data=data, params=params, **kw)

    # -- envelope handling (mirrors src/http/http.ts) -----------------

    def _handle_response(self, resp: requests.Response) -> Any:
        try:
            body = resp.json()
        except ValueError:
            body = None
        if not isinstance(body, dict):
            if 200 <= resp.status_code < 300:
                return body
            raise WmsError(resp.status_code, f"HTTP {resp.status_code} from {resp.url}", body)

        code = body.get("code")
        msg = body.get("msg") or body.get("message") or "请求错误"
        data = body.get("data")

        if resp.status_code == UNAUTHORIZED or code == UNAUTHORIZED:
            raise WmsAuthError(UNAUTHORIZED, msg or "登录状态已过期，请重新登录", data)
        if 200 <= resp.status_code < 300:
            if code == CONFIRM_CODE:
                # GUI: showModal(msg) then proceed with data.
                self.last_code, self.last_msg = code, msg
                return data
            if code not in SUCCESS_CODES:
                raise WmsError(code, msg, data)
            self.last_code, self.last_msg = code, msg
            return data
        raise WmsError(resp.status_code, msg or f"HTTP {resp.status_code}", data)

    # -- persistence-friendly ----------------------------------------

    def describe(self) -> dict:
        return {"base_url": self.base_url, "token": self.token}

    def to_json(self) -> str:
        return json.dumps(self.describe(), ensure_ascii=False)
