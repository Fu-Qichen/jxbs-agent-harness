"""Session state: server config, auth token, user snapshot, and scan drafts.

Persisted as JSON. Location: ``~/.cli-anything/gaosirobot-wms/session.json``,
overridable with ``CLI_ANYTHING_WMS_SESSION`` (used by tests).
"""

from __future__ import annotations

import copy
import json
import os
import sys
from pathlib import Path

from cli_anything.gaosirobot_wms.core.client import SERVER_PRESETS

# Draft groups that follow the GUI's scan-accumulate-submit workflows.
DRAFT_GROUPS = ("inbound", "transfer", "warehouse", "finished", "reject", "return")

DEFAULT_SERVER_CONFIG = {
    "environment": "production",
    "base_url": SERVER_PRESETS["production"],
}


def session_path() -> Path:
    override = os.environ.get("CLI_ANYTHING_WMS_SESSION")
    if override:
        return Path(override)
    home = Path.home()
    return home / ".cli-anything" / "gaosirobot-wms" / "session.json"


class Session:
    """Stateful CLI session — the file-backed equivalent of the app's Pinia stores."""

    def __init__(self, data: dict | None = None, path: Path | None = None) -> None:
        self.path = Path(path) if path else session_path()
        self._data = data if data is not None else self._load()
        self._dirty = False

    # -- persistence ---------------------------------------------------

    def _load(self) -> dict:
        try:
            with open(self.path, encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                return data
        except (OSError, ValueError):
            pass
        return {}

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self._data, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, self.path)
        self._dirty = False

    @property
    def dirty(self) -> bool:
        return self._dirty

    # -- server --------------------------------------------------------

    @property
    def server(self) -> dict:
        cfg = self._data.get("server")
        if not cfg:
            cfg = copy.deepcopy(DEFAULT_SERVER_CONFIG)
            self._data["server"] = cfg
            self._dirty = True
        return cfg

    @property
    def base_url(self) -> str:
        return self.server.get("base_url") or SERVER_PRESETS["production"]

    def use_preset(self, environment: str) -> str:
        if environment not in SERVER_PRESETS:
            raise ValueError(f"unknown environment {environment!r}")
        self.server.update({"environment": environment, "base_url": SERVER_PRESETS[environment]})
        self._dirty = True
        return self.base_url

    def use_custom(self, url: str) -> str:
        url = url.strip().rstrip("/")
        if not url.lower().startswith(("http://", "https://")):
            url = "http://" + url
        self.server.update({"environment": "custom", "base_url": url})
        self._dirty = True
        return self.base_url

    # -- auth ----------------------------------------------------------

    @property
    def token(self) -> str | dict | None:
        return self._data.get("token")

    @token.setter
    def token(self, value: str | dict | None) -> None:
        self._data["token"] = value
        self._dirty = True

    @property
    def user(self) -> dict | None:
        return self._data.get("user")

    @user.setter
    def user(self, value: dict | None) -> None:
        self._data["user"] = value
        self._dirty = True

    @property
    def is_logged_in(self) -> bool:
        tok = self.token
        if isinstance(tok, str):
            return bool(tok)
        if isinstance(tok, dict):
            return bool(tok.get("accessToken"))
        return False

    # -- drafts ----------------------------------------------------------

    def draft(self, group: str) -> list:
        if group not in DRAFT_GROUPS:
            raise ValueError(f"unknown draft group {group!r}")
        drafts = self._data.setdefault("drafts", {})
        if group not in drafts or not isinstance(drafts[group], list):
            drafts[group] = []
            self._dirty = True
        return drafts[group]

    def draft_add(self, group: str, item: dict) -> int:
        items = self.draft(group)
        items.append(item)
        self._dirty = True
        return len(items) - 1

    def draft_remove(self, group: str, index: int) -> dict:
        items = self.draft(group)
        item = items.pop(index)
        self._dirty = True
        return item

    def draft_clear(self, group: str) -> int:
        items = self.draft(group)
        count = len(items)
        if count:
            items.clear()
            self._dirty = True
        return count

    def draft_popcodes(self, group: str) -> list[str]:
        """packCodes already in the draft (used by ScanDBDPackCode requests)."""
        return [it.get("packCode") for it in self.draft(group) if it.get("packCode")]

    # -- misc ------------------------------------------------------------

    def clear_auth(self) -> None:
        """Logout: drop token and user (server switch also does this, per app)."""
        self._data.pop("token", None)
        self._data.pop("user", None)
        self._dirty = True

    def snapshot(self) -> dict:
        return copy.deepcopy(self._data)

    # display helper
    def summary(self) -> str:
        server = self.server
        user = self.user or {}
        login = "yes" if self.is_logged_in else "no"
        who = f"{user.get('userName', '?')} ({user.get('nickName', '')})" if user else "-"
        drafts = {
            g: len(self._data.get("drafts", {}).get(g, []))
            for g in DRAFT_GROUPS
            if self._data.get("drafts", {}).get(g)
        }
        lines = [
            f"server: {self.base_url}  [{server.get('environment', '?')}]",
            f"logged in: {login}  user: {who}",
            f"drafts: {drafts if drafts else '{}'}",
        ]
        return "\n".join(lines)
