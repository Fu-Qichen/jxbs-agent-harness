"""Sales domain — shipping plans and sales outbound (src/api/sales-outbound-api.ts,
shipping-plan-api.ts). Both submits carry their parameters as query string with an
empty body, exactly like the GUI's ``http.post(url, null, data)`` calls."""

from __future__ import annotations

from typing import Any

from cli_anything.gaosirobot_wms.core.client import WmsClient


# -- shipping plans (发货计划) --------------------------------------------


def list_shipping_plans(client: WmsClient, c_code: str | None = None,
                        begin_date: str | None = None, end_date: str | None = None) -> dict:
    params = {k: v for k, v in
              {"cCode": c_code, "beginDate": begin_date, "endDate": end_date}.items() if v}
    return client.get("/MyClass/MyApi/GetU9CShipPlanList", params)


def submit_shipping_plan(client: WmsClient, ship_plan_code: str) -> Any:
    """POST /MyClass/MyApi/AddXSCK?shipPlanCode=... (empty body)."""
    return client.post("/MyClass/MyApi/AddXSCK", None, {"shipPlanCode": ship_plan_code})


# -- sales outbound (销售出库) ---------------------------------------------


def list_outbounds(client: WmsClient, c_code: str | None = None,
                   begin_date: str | None = None, end_date: str | None = None) -> dict:
    params = {k: v for k, v in
              {"cCode": c_code, "beginDate": begin_date, "endDate": end_date}.items() if v}
    return client.get("/MyClass/MyApi/GetWmsXSCKList", params)


def confirm_outbound(client: WmsClient, c_code: str, d_date: str,
                     user_code: str, user_name: str) -> Any:
    """POST /MyClass/MyApi/ConfirmXSCK?dDate=&createUserCode=&createUserName=&cCode=."""
    return client.post("/MyClass/MyApi/ConfirmXSCK", None, {
        "dDate": d_date,
        "createUserCode": user_code,
        "createUserName": user_name,
        "cCode": c_code,
    })
