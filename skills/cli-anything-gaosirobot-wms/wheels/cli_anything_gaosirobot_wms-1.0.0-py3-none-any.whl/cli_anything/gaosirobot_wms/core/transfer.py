"""Transfers — production (AddDBDMom) and warehouse (AddDBD) flows."""

from __future__ import annotations

from typing import Any

from cli_anything.gaosirobot_wms.core.client import WmsClient

# -- production transfer (生产调拨) ---------------------------------------


def get_mo_detail(client: WmsClient, mo_code: str) -> dict:
    return client.get("/MyClass/MyMethod/GetMomOrderDetail", {"moCode": mo_code})


def scan_pack(client: WmsClient, current_pack_code: str, scanned: list[str]) -> dict:
    """POST ScanDBDPackCode — validate the next package against those scanned."""
    return client.post("/MyClass/MyApi/ScanDBDPackCode",
                       {"currentPackCode": current_pack_code, "packCodes": scanned})


def scan_pack_back(client: WmsClient, pack_code: str, c_pos_code: str) -> dict:
    """GET ScanDBDPackCodeBack — undo one scan."""
    return client.get("/MyClass/MyApi/ScanDBDPackCodeBack",
                      {"PackCode": pack_code, "cPosCode": c_pos_code})


def build_transfer_request(items: list[dict], mo_code: str, wh_out: str, wh_in: str,
                           d_date: str, user_code: str, user_name: str,
                           default_pos_in: str | None = None) -> dict:
    if not items:
        raise ValueError("transfer draft is empty — scan at least one package")
    details = []
    for it in items:
        pos_in = it.get("cPosCodeIn") or default_pos_in
        if not pos_in:
            raise ValueError(f"package {it.get('packCode')!r} has no target bin; pass --pos-in")
        details.append({
            "cInvCode": it.get("cInvCode", ""),
            "cInvName": it.get("cInvName", ""),
            "cInvStd": it.get("cInvStd", ""),
            "cComUnitName": it.get("cComUnitName", ""),
            "packCode": it.get("packCode", ""),
            "packCodeMax": it.get("packCodeMax", ""),
            "cPosCodeOut": it.get("cPosCode", ""),
            "cPosCodeIn": pos_in,
            "cBatch": it.get("cBatch", ""),
            "iQuantity": str(it.get("iQuantity", "")),
        })
    return {
        "dDate": d_date,
        "cWhCodeOut": wh_out,
        "cWhCodeIn": wh_in,
        "moCode": mo_code,
        "createUserCode": user_code,
        "createUserName": user_name,
        "datas": details,
    }


def submit_transfer(client: WmsClient, payload: dict) -> Any:
    """POST /MyClass/MyApi/AddDBDMom."""
    return client.post("/MyClass/MyApi/AddDBDMom", payload)


# -- warehouse transfer (非生产调拨) ---------------------------------------


def list_warehouses(client: WmsClient, page_size: int = 1000) -> dict:
    return client.get("/MyClass/MyMethod/GetWareHouseList",
                      {"pageNum": 1, "pageSize": page_size})


def scan_warehouse_pack(client: WmsClient, current_pack_code: str, scanned: list[str],
                        wh_out: str, wh_in: str, pos_in: str) -> dict:
    """POST ScanDBDPackCode2."""
    return client.post("/MyClass/MyApi/ScanDBDPackCode2", {
        "PackCode": {"currentPackCode": current_pack_code, "packCodes": scanned},
        "cWhCodeOut": wh_out,
        "cWhCodeIn": wh_in,
        "cPosCodeIn": pos_in,
    })


def build_warehouse_request(items: list[dict], wh_out: str, wh_in: str,
                            d_date: str, user_code: str, user_name: str,
                            default_pos_in: str | None = None) -> dict:
    if not items:
        raise ValueError("warehouse transfer draft is empty — scan at least one package")
    details = []
    for it in items:
        pos_in = it.get("cPosCodeIn") or default_pos_in
        pos_out = it.get("cPosCode") or ""
        details.append({
            "cInvCode": it.get("cInvCode", ""),
            "cInvName": it.get("cInvName", ""),
            "cInvStd": it.get("cInvStd", ""),
            "cComUnitName": it.get("cComUnitName", ""),
            "packCode": it.get("packCode", ""),
            "packCodeMax": it.get("packCodeMax", ""),
            "cBatch": it.get("cBatch", ""),
            "iQuantity": str(it.get("iQuantity", "")),
            "cPosCodeOut": pos_out,
            "cPosCodeIn": pos_in,
        })
    return {
        "dDate": d_date,
        "cWhCodeOut": wh_out,
        "cWhCodeIn": wh_in,
        "createUserCode": user_code,
        "createUserName": user_name,
        "datas": details,
    }


def submit_warehouse_transfer(client: WmsClient, payload: dict) -> Any:
    """POST /MyClass/MyApi/AddDBD."""
    return client.post("/MyClass/MyApi/AddDBD", payload)
