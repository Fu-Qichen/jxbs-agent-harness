"""Main CLI entry point — cli-anything-gaosirobot-wms.

Stateful harness for the Gaosi WMS backend (gaosirobot-wms-app).

- One-shot commands + interactive REPL (invoke with no arguments or ``repl``).
- ``--json`` global flag (or ``CLI_ANYTHING_JSON=1``) for agent consumption.
- ``--dry-run`` global flag: mutations do not touch the server (submits print
  the payload) and the session file is never persisted.
- Auto-save: every mutating one-shot command persists the session before exit
  unless ``--dry-run`` is active.
"""

from __future__ import annotations

import json
import os
import shlex
import sys

import click

from cli_anything.gaosirobot_wms import CLI_NAME, SOFTWARE, __version__
from cli_anything.gaosirobot_wms.core import auth
from cli_anything.gaosirobot_wms.core.client import (
    SERVER_PRESETS,
    WmsAuthError,
    WmsClient,
    WmsError,
    WmsTransportError,
)
from cli_anything.gaosirobot_wms.core.finished import (
    build_inbound_request as build_finished_request,
    get_material,
    get_recommended_position,
    submit_inbound as submit_finished,
)
from cli_anything.gaosirobot_wms.core.purchasing import (
    build_inbound_request,
    get_bin,
    get_delivery_note,
    get_package_max,
    get_package_min,
    inbound_scan,
    list_bins,
    submit_arrival,
    submit_inbound,
)
from cli_anything.gaosirobot_wms.core.returns import (
    build_reject_request,
    build_return_request,
    list_messages,
    package_status,
    read_message,
    reject_scan,
    return_scan,
    submit_reject,
    submit_return,
)
from cli_anything.gaosirobot_wms.core.sales import (
    confirm_outbound,
    list_outbounds,
    list_shipping_plans,
    submit_shipping_plan,
)
from cli_anything.gaosirobot_wms.core.session import DRAFT_GROUPS, Session
from cli_anything.gaosirobot_wms.core.transfer import (
    build_transfer_request,
    build_warehouse_request,
    get_mo_detail,
    list_warehouses,
    scan_pack,
    scan_pack_back,
    scan_warehouse_pack,
    submit_transfer,
    submit_warehouse_transfer,
)
from cli_anything.gaosirobot_wms.utils.output import (
    emit_json,
    emit_value,
    fail,
    print_table,
    today,
)


# ---------------------------------------------------------------------------
# runtime plumbing
# ---------------------------------------------------------------------------


class Runtime:
    """Per-invocation state shared by all commands."""

    def __init__(self, json_mode: bool, dry_run: bool) -> None:
        self.json_mode = json_mode
        self.dry_run = dry_run
        self.session = Session()

    @property
    def logged_in(self) -> bool:
        return self.session.is_logged_in

    def client(self) -> WmsClient:
        if not self.session.base_url:
            fail("no server configured; run `server use <production|test|custom>`",
                 json_mode=self.json_mode)
        return WmsClient(self.session.base_url, self.session.token)

    def notice(self, message: str) -> None:
        if not self.json_mode:
            click.echo(message, err=True)

    def save(self) -> None:
        """Auto-save the session after a one-shot mutation (suppressed by --dry-run)."""
        if self.dry_run:
            self.notice("(dry-run: session not saved)")
        else:
            self.session.save()

    def emit(self, data, notice: str | None = None) -> None:
        """Emit the last API result honoring --json; attach 250-confirm notices."""
        code = self._client_code
        msg = self._client_msg
        if notice and not self.json_mode:
            click.echo(f"NOTE: {notice}", err=True)
        if self.json_mode:
            emit_json(True, code, notice or msg, data)
        else:
            emit_value(data)

    def set_client_meta(self, client: WmsClient) -> None:
        self._client_code = client.last_code
        self._client_msg = client.last_msg

    _client_code: int | None = None
    _client_msg: str | None = None


class _ApiError(click.ClickException):
    pass


def api_call(rt: Runtime, fn, *args, **kwargs):
    """Run an API call, translating domain errors into clean CLI failures."""
    client = rt.client()
    try:
        result = fn(client, *args, **kwargs)
    except WmsAuthError as exc:
        fail(f"authentication expired (401): {exc.msg}; run `auth login`",
             code=401, json_mode=rt.json_mode)
    except WmsTransportError as exc:
        fail(f"network failure: {exc}", json_mode=rt.json_mode)
    except WmsError as exc:
        fail(f"API error {exc.code}: {exc.msg}", code=exc.code, data=exc.data,
             json_mode=rt.json_mode)
    except ValueError as exc:
        fail(str(exc), json_mode=rt.json_mode)
    rt.set_client_meta(client)
    return result


def creator_args(rt: Runtime, user_code: str | None, user_name: str | None) -> tuple[str, str]:
    """Document creator: CLI options, else the login user snapshot."""
    user = rt.session.user or {}
    code = user_code or user.get("userName") or ""
    name = user_name or user.get("nickName") or user.get("userName") or ""
    if not code:
        fail("no creator available: pass --user-code/--user-name or run `auth login`",
             json_mode=rt.json_mode)
    return code, name


def load_json_argument(data: str | None, file) -> dict:
    if file is not None:
        try:
            return json.load(file)
        except ValueError as exc:
            fail(f"invalid JSON file: {exc}")
    if data:
        try:
            return json.loads(data)
        except ValueError as exc:
            fail(f"invalid JSON: {exc}")
    fail("no payload: pass JSON via --data or --file")


@click.group()
@click.version_option(__version__, prog_name=CLI_NAME)
@click.option("--json", "json_mode", is_flag=True, default=False,
              envvar="CLI_ANYTHING_JSON", help="machine-readable JSON output.")
@click.option("--dry-run", is_flag=True, default=False,
              help="do not persist the session or submit documents.")
@click.pass_context
def cli(ctx: click.Context, json_mode: bool, dry_run: bool) -> None:
    """cli-anything harness for Gaosi WMS (gaosirobot-wms-app).

    Use --json for agent-readable output. Mutating commands auto-save the
    session unless --dry-run is given.
    """
    ctx.obj = Runtime(json_mode, dry_run)


def build_or_fail(rt: Runtime, build_fn, *args):
    """Run a payload builder; turn draft-shape ValueErrors into clean failures."""
    try:
        return build_fn(*args)
    except ValueError as exc:
        fail(str(exc), json_mode=rt.json_mode)


# ---------------------------------------------------------------------------
# server
# ---------------------------------------------------------------------------


@cli.group()
def server() -> None:
    """Server environment management (production / test / custom)."""


@server.command("show")
@click.pass_obj
def server_show(rt: Runtime) -> None:
    """Show the current server configuration."""
    cfg = dict(rt.session.server)
    cfg["base_url"] = rt.session.base_url
    presets = SERVER_PRESETS
    cfg["presets"] = presets
    rt.emit(cfg)


@server.command("use")
@click.argument("environment", type=click.Choice(["production", "test", "custom"]))
@click.option("--url", help="base URL for the custom environment.")
@click.pass_obj
def server_use(rt: Runtime, environment: str, url: str | None) -> None:
    """Switch server environment (clears login state, like the GUI)."""
    if environment == "custom":
        if not url:
            fail("--url is required for the custom environment", json_mode=rt.json_mode)
        base = rt.session.use_custom(url)
    else:
        base = rt.session.use_preset(environment)
    rt.session.clear_auth()  # app clears login state on server switch
    rt.save()
    rt.emit({"environment": environment, "base_url": base},
            notice="login state cleared on server switch")


@server.command("probe")
@click.option("--url", help="probe an arbitrary base URL instead of the current one.")
@click.pass_obj
def server_probe(rt: Runtime, url: str | None) -> None:
    """Check server connectivity (mirrors the GUI's save-time probe)."""
    import requests as _requests

    base = (url or rt.session.base_url).rstrip("/")
    try:
        resp = _requests.get(base + "/", timeout=5)
        ok = resp.status_code < 500
        detail = f"HTTP {resp.status_code}"
    except _requests.RequestException as exc:
        ok, detail = False, str(exc)
    rt.emit({"base_url": base, "reachable": ok, "detail": detail})


# ---------------------------------------------------------------------------
# auth
# ---------------------------------------------------------------------------


@cli.group("auth")
def authgrp() -> None:
    """Authentication (login / logout / whoami)."""


@authgrp.command("login")
@click.option("-u", "--username", prompt=True)
@click.option("-p", "--password", envvar="WMS_PASSWORD", default=None,
              prompt=True, hide_input=True)
@click.pass_obj
def auth_login(rt: Runtime, username: str, password: str) -> None:
    """Log in and persist the token (POST /MobileLogin)."""
    client = rt.client()
    try:
        token = auth.login(client, username, password)
    except WmsTransportError as exc:
        fail(f"network failure: {exc}", json_mode=rt.json_mode)
    except WmsError as exc:
        fail(f"login failed ({exc.code}): {exc.msg}", code=exc.code,
             json_mode=rt.json_mode)
    rt.session.token = token
    # fetch user snapshot for document creator fields (best-effort)
    try:
        authed = WmsClient(rt.session.base_url, token)
        info = auth.get_user_info(authed)
        rt.session.user = info.get("user") if isinstance(info, dict) else None
        rt.set_client_meta(authed)
    except WmsError:
        pass
    rt.save()
    rt.emit({"username": username, "token": token},
            notice=rt._client_msg or "login ok")


@authgrp.command("logout")
@click.pass_obj
def auth_logout(rt: Runtime) -> None:
    """Log out; clears token and user snapshot."""
    if rt.session.is_logged_in:
        client = rt.client()
        try:
            auth.logout(client)
            rt.set_client_meta(client)
        except (WmsError, WmsTransportError):
            rt.notice("logout request failed; clearing local state anyway")
    rt.session.clear_auth()
    rt.save()
    rt.emit({"logged_in": False})


@authgrp.command("status")
@click.pass_obj
def auth_status(rt: Runtime) -> None:
    """Show login state and token summary."""
    tok = rt.session.token
    summary: dict = {"logged_in": rt.session.is_logged_in}
    if isinstance(tok, dict):
        summary["mode"] = "double"
        summary["expires_in"] = {"access": tok.get("accessExpiresIn"),
                                 "refresh": tok.get("refreshExpiresIn")}
    elif isinstance(tok, str) and tok:
        summary["mode"] = "single"
        summary["token_prefix"] = tok[:8] + "..."
    summary["user"] = rt.session.user
    rt.emit(summary)


@authgrp.command("whoami")
@click.pass_obj
def auth_whoami(rt: Runtime) -> None:
    """Fetch /getInfo from the server."""
    rt.emit(api_call(rt, auth.get_user_info))


# ---------------------------------------------------------------------------
# purchasing
# ---------------------------------------------------------------------------


@cli.group()
def purchasing() -> None:
    """Purchasing: delivery notes, package scans, bins, arrival, inbound."""


@purchasing.command("delivery")
@click.argument("c_code")
@click.pass_obj
def purchasing_delivery(rt: Runtime, c_code: str) -> None:
    """Look up an SRM delivery note (GetDeliveryDoc)."""
    rt.emit(api_call(rt, get_delivery_note, c_code))


@purchasing.command("package")
@click.argument("pack_code")
@click.pass_obj
def purchasing_package(rt: Runtime, pack_code: str) -> None:
    """Scan a package for receiving (GetPackageMin)."""
    rt.emit(api_call(rt, get_package_min, pack_code))


@purchasing.command("package-max")
@click.argument("package_id")
@click.pass_obj
def purchasing_package_max(rt: Runtime, package_id: str) -> None:
    """List small packages under a max package (GetPackageMax)."""
    rt.emit(api_call(rt, get_package_max, package_id))


@purchasing.command("bin")
@click.argument("c_pos_code")
@click.pass_obj
def purchasing_bin(rt: Runtime, c_pos_code: str) -> None:
    """Look up one bin (GetPosition)."""
    rt.emit(api_call(rt, get_bin, c_pos_code))


@purchasing.command("bins")
@click.argument("c_pos_name")
@click.pass_obj
def purchasing_bins(rt: Runtime, c_pos_name: str) -> None:
    """Search bins by name (GetPositionList)."""
    rt.emit(api_call(rt, list_bins, c_pos_name))


@purchasing.command("arrival-submit")
@click.option("--data", help="GRN payload as JSON text.")
@click.option("--file", type=click.File("r", encoding="utf-8"),
              help="GRN payload as a JSON file ('-' = stdin).")
@click.pass_obj
def purchasing_arrival_submit(rt: Runtime, data: str | None, file) -> None:
    """Submit an arrival voucher (AddArrivalVouch) from a JSON payload."""
    grn = load_json_argument(data, file)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": grn})
        return
    rt.emit(api_call(rt, submit_arrival, grn))


# -- inbound draft flow (CGRK) --


@purchasing.command("inbound-scan")
@click.argument("pack_code")
@click.option("--pos", help="target bin code (cPosCode) stored with the draft item.")
@click.pass_obj
def purchasing_inbound_scan(rt: Runtime, pack_code: str, pos: str | None) -> None:
    """Scan a package into the inbound draft (GetPackageMin_CGRK)."""
    item = api_call(rt, inbound_scan, pack_code, pos)
    if pos:
        item = dict(item)
        item["cPosCode"] = pos
    idx = rt.session.draft_add("inbound", item)
    rt.save()  # auto-save after one-shot mutation
    rt.emit({"draft_index": idx, "item": item})


@purchasing.command("inbound-list")
@click.pass_obj
def purchasing_inbound_list(rt: Runtime) -> None:
    """Show the inbound draft."""
    rt.emit(rt.session.draft("inbound"))


@purchasing.command("inbound-remove")
@click.argument("index", type=int)
@click.pass_obj
def purchasing_inbound_remove(rt: Runtime, index: int) -> None:
    """Remove one draft item by index."""
    try:
        item = rt.session.draft_remove("inbound", index)
    except IndexError:
        fail(f"draft index {index} out of range", json_mode=rt.json_mode)
    rt.save()
    rt.emit({"removed": item})


@purchasing.command("inbound-submit")
@click.option("--date", "d_date", default=today, show_default="today",
              help="document date (YYYY-MM-DD).")
@click.option("--pos", default=None, help="default bin for items without one.")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def purchasing_inbound_submit(rt: Runtime, d_date: str, pos: str | None,
                              user_code: str | None, user_name: str | None) -> None:
    """Submit the inbound draft as a document (AddCGRK)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_inbound_request,
                            rt.session.draft("inbound"), d_date, code, name, pos)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_inbound, payload))
    rt.session.draft_clear("inbound")
    rt.save()


@purchasing.command("inbound-clear")
@click.pass_obj
def purchasing_inbound_clear(rt: Runtime) -> None:
    """Clear the inbound draft."""
    n = rt.session.draft_clear("inbound")
    rt.save()
    rt.emit({"cleared": n})


# ---------------------------------------------------------------------------
# transfers
# ---------------------------------------------------------------------------


@cli.group()
def transfer() -> None:
    """Transfers: production (AddDBDMom) and warehouse (AddDBD) flows."""


@transfer.command("warehouses")
@click.pass_obj
def transfer_warehouses(rt: Runtime) -> None:
    """List warehouses (GetWareHouseList)."""
    data = api_call(rt, list_warehouses)
    rt.emit(data.get("datas") if isinstance(data, dict) else data)


@transfer.command("mo")
@click.argument("mo_code")
@click.pass_obj
def transfer_mo(rt: Runtime, mo_code: str) -> None:
    """Look up a production order (GetMomOrderDetail)."""
    rt.emit(api_call(rt, get_mo_detail, mo_code))


@transfer.command("scan")
@click.argument("pack_code")
@click.option("--pos-in", help="target bin stored with the draft item.")
@click.pass_obj
def transfer_scan(rt: Runtime, pack_code: str, pos_in: str | None) -> None:
    """Scan a package into the production-transfer draft (ScanDBDPackCode)."""
    item = api_call(rt, scan_pack, pack_code, rt.session.draft_popcodes("transfer"))
    if pos_in:
        item = dict(item)
        item["cPosCodeIn"] = pos_in
    idx = rt.session.draft_add("transfer", item)
    rt.save()
    rt.emit({"draft_index": idx, "item": item})


@transfer.command("scan-back")
@click.argument("pack_code")
@click.option("--pos", required=True, help="bin used when the package was scanned.")
@click.pass_obj
def transfer_scan_back(rt: Runtime, pack_code: str, pos: str) -> None:
    """Undo one scan (ScanDBDPackCodeBack)."""
    rt.emit(api_call(rt, scan_pack_back, pack_code, pos))


@transfer.command("submit")
@click.argument("mo_code")
@click.option("--wh-out", required=True)
@click.option("--wh-in", required=True)
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--pos-in", default=None, help="default target bin.")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def transfer_submit(rt: Runtime, mo_code: str, wh_out: str, wh_in: str,
                    d_date: str, pos_in: str | None,
                    user_code: str | None, user_name: str | None) -> None:
    """Submit the production-transfer draft (AddDBDMom)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_transfer_request,
                            rt.session.draft("transfer"), mo_code, wh_out,
                            wh_in, d_date, code, name, pos_in)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_transfer, payload))
    rt.session.draft_clear("transfer")
    rt.save()


@transfer.command("scan2")
@click.argument("pack_code")
@click.option("--wh-out", required=True)
@click.option("--wh-in", required=True)
@click.option("--pos-in", required=True)
@click.pass_obj
def transfer_scan2(rt: Runtime, pack_code: str, wh_out: str, wh_in: str,
                   pos_in: str) -> None:
    """Scan a package for a warehouse transfer (ScanDBDPackCode2)."""
    item = api_call(rt, scan_warehouse_pack, pack_code,
                    rt.session.draft_popcodes("warehouse"), wh_out, wh_in, pos_in)
    item = dict(item)
    item["cPosCodeIn"] = pos_in
    idx = rt.session.draft_add("warehouse", item)
    rt.save()
    rt.emit({"draft_index": idx, "item": item})


@transfer.command("submit-warehouse")
@click.option("--wh-out", required=True)
@click.option("--wh-in", required=True)
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--pos-in", default=None, help="default target bin.")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def transfer_submit_warehouse(rt: Runtime, wh_out: str, wh_in: str, d_date: str,
                              pos_in: str | None, user_code: str | None,
                              user_name: str | None) -> None:
    """Submit the warehouse-transfer draft (AddDBD)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_warehouse_request,
                            rt.session.draft("warehouse"), wh_out, wh_in,
                            d_date, code, name, pos_in)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_warehouse_transfer, payload))
    rt.session.draft_clear("warehouse")
    rt.save()


@transfer.command("list")
@click.argument("group", type=click.Choice(["transfer", "warehouse"]))
@click.pass_obj
def transfer_list(rt: Runtime, group: str) -> None:
    """Show a transfer draft."""
    rt.emit(rt.session.draft(group))


# ---------------------------------------------------------------------------
# finished goods
# ---------------------------------------------------------------------------


@cli.group()
def finished() -> None:
    """Finished-goods inbound (成品入库, AddCCPRK)."""


@finished.command("position")
@click.pass_obj
def finished_position(rt: Runtime) -> None:
    """Get the recommended bin (GetPosition_CCPRK)."""
    rt.emit(api_call(rt, get_recommended_position))


@finished.command("material")
@click.argument("bar_code_under")
@click.option("--pos", help="target bin stored with the draft item.")
@click.pass_obj
def finished_material(rt: Runtime, bar_code_under: str, pos: str | None) -> None:
    """Scan a finished-goods barcode into the draft (GetMaterial_CCPRK)."""
    item = api_call(rt, get_material, bar_code_under)
    if pos:
        item = dict(item)
        item["cPosCode"] = pos
    idx = rt.session.draft_add("finished", item)
    rt.save()
    rt.emit({"draft_index": idx, "item": item})


@finished.command("submit")
@click.option("--wh", required=True, help="warehouse code (cWhCode).")
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--pos", default=None, help="default bin for items without one.")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def finished_submit(rt: Runtime, wh: str, d_date: str, pos: str | None,
                    user_code: str | None, user_name: str | None) -> None:
    """Submit the finished-goods draft (AddCCPRK)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_finished_request,
                            rt.session.draft("finished"), wh, d_date,
                            code, name, pos)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_finished, payload))
    rt.session.draft_clear("finished")
    rt.save()


@finished.command("list")
@click.pass_obj
def finished_list(rt: Runtime) -> None:
    """Show the finished-goods draft."""
    rt.emit(rt.session.draft("finished"))


# ---------------------------------------------------------------------------
# sales
# ---------------------------------------------------------------------------


@cli.group()
def sales() -> None:
    """Shipping plans and sales outbound."""


@sales.command("plans")
@click.option("--code", default=None)
@click.option("--begin-date", default=None)
@click.option("--end-date", default=None)
@click.pass_obj
def sales_plans(rt: Runtime, code: str | None, begin_date: str | None,
                end_date: str | None) -> None:
    """List shipping plans (GetU9CShipPlanList)."""
    data = api_call(rt, list_shipping_plans, code, begin_date, end_date)
    rt.emit(data.get("datas") if isinstance(data, dict) else data)


@sales.command("plan-submit")
@click.argument("ship_plan_code")
@click.pass_obj
def sales_plan_submit(rt: Runtime, ship_plan_code: str) -> None:
    """Generate a sales-outbound doc from a shipping plan (AddXSCK)."""
    rt.emit(api_call(rt, submit_shipping_plan, ship_plan_code))


@sales.command("outbounds")
@click.option("--code", default=None)
@click.option("--begin-date", default=None)
@click.option("--end-date", default=None)
@click.pass_obj
def sales_outbounds(rt: Runtime, code: str | None, begin_date: str | None,
                    end_date: str | None) -> None:
    """List sales-outbound documents (GetWmsXSCKList)."""
    data = api_call(rt, list_outbounds, code, begin_date, end_date)
    rt.emit(data.get("datas") if isinstance(data, dict) else data)


@sales.command("outbound-confirm")
@click.argument("c_code")
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def sales_outbound_confirm(rt: Runtime, c_code: str, d_date: str,
                           user_code: str | None, user_name: str | None) -> None:
    """Confirm a sales-outbound document (ConfirmXSCK)."""
    code, name = creator_args(rt, user_code, user_name)
    rt.emit(api_call(rt, confirm_outbound, c_code, d_date, code, name))


# ---------------------------------------------------------------------------
# returns / trace / messages
# ---------------------------------------------------------------------------


@cli.group()
def returns() -> None:
    """Purchase return (AddCGTH) and reject (AddCGJS) flows."""


@returns.command("reject-scan")
@click.argument("pack_code")
@click.pass_obj
def returns_reject_scan(rt: Runtime, pack_code: str) -> None:
    """Scan a package into the reject draft (GetPackageMin_CGJS)."""
    item = api_call(rt, reject_scan, pack_code)
    idx = rt.session.draft_add("reject", item)
    rt.save()
    rt.emit({"draft_index": idx, "item": item})


@returns.command("reject-submit")
@click.option("--reason", required=True, help="reject reason (cReason).")
@click.option("--memo", default="", help="memo (cMemo).")
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def returns_reject_submit(rt: Runtime, reason: str, memo: str, d_date: str,
                          user_code: str | None, user_name: str | None) -> None:
    """Submit the reject draft (AddCGJS)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_reject_request,
                            rt.session.draft("reject"), d_date, reason,
                            memo, code, name)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_reject, payload))
    rt.session.draft_clear("reject")
    rt.save()


@returns.command("return-scan")
@click.argument("pack_code")
@click.pass_obj
def returns_return_scan(rt: Runtime, pack_code: str) -> None:
    """Scan a package into the return draft (GetPackageMin_CGTH)."""
    item = api_call(rt, return_scan, pack_code)
    idx = rt.session.draft_add("return", item)
    rt.save()
    rt.emit({"draft_index": idx, "item": item})


@returns.command("return-submit")
@click.option("--reason", required=True)
@click.option("--memo", default="")
@click.option("--date", "d_date", default=today, show_default="today")
@click.option("--user-code", default=None)
@click.option("--user-name", default=None)
@click.pass_obj
def returns_return_submit(rt: Runtime, reason: str, memo: str, d_date: str,
                          user_code: str | None, user_name: str | None) -> None:
    """Submit the return draft (AddCGTH)."""
    code, name = creator_args(rt, user_code, user_name)
    payload = build_or_fail(rt, build_return_request,
                            rt.session.draft("return"), d_date, reason,
                            memo, code, name)
    if rt.dry_run:
        rt.emit({"dry_run": True, "payload": payload})
        return
    rt.emit(api_call(rt, submit_return, payload))
    rt.session.draft_clear("return")
    rt.save()


@returns.command("list")
@click.argument("group", type=click.Choice(["reject", "return"]))
@click.pass_obj
def returns_list(rt: Runtime, group: str) -> None:
    """Show a reject/return draft."""
    rt.emit(rt.session.draft(group))


@cli.command("trace")
@click.argument("pack_code")
@click.pass_obj
def trace(rt: Runtime, pack_code: str) -> None:
    """Package traceability query (GetPackageMinStaus)."""
    rt.emit(api_call(rt, package_status, pack_code))


@cli.group()
def messages() -> None:
    """System messages (SysUserMsg)."""


@messages.command("list")
@click.option("--all", "show_all", is_flag=True, help="include read messages.")
@click.option("--types", "msg_types", default=None, help="filter by msgType.")
@click.pass_obj
def messages_list(rt: Runtime, show_all: bool, msg_types: str | None) -> None:
    """List system messages (unread by default)."""
    data = api_call(rt, list_messages, None if show_all else False, msg_types)
    rt.emit(data.get("result") if isinstance(data, dict) else data)


@messages.command("read")
@click.argument("msg_id")
@click.argument("msg_type")
@click.pass_obj
def messages_read(rt: Runtime, msg_id: str, msg_type: str) -> None:
    """Mark a message read (POST /SysUserMsg/read/{id}/{type})."""
    rt.emit(api_call(rt, read_message, msg_id, msg_type))


# ---------------------------------------------------------------------------
# raw escape hatch + drafts + repl
# ---------------------------------------------------------------------------


@cli.command("request", context_settings={"ignore_unknown_options": True})
@click.argument("method", type=click.Choice(["GET", "POST", "PUT", "DELETE"]))
@click.argument("path")
@click.option("--data", default=None, help="JSON request body.")
@click.option("-q", "--query", multiple=True, help="query param k=v (repeatable).")
@click.pass_obj
def request(rt: Runtime, method: str, path: str, data: str | None,
            query: tuple[str, ...]) -> None:
    """Raw API escape hatch: request GET /MyClass/MyApi/GetPackageMin -q PackCode=X."""
    params = {}
    for item in query:
        key, _, value = item.partition("=")
        params[key] = value
    payload = json.loads(data) if data else None
    rt.emit(api_call(rt, lambda cl: cl.request(method, path, payload, params)))


@cli.group("draft")
def draftgrp() -> None:
    """Draft (scan cart) management across workflows."""


@draftgrp.command("show")
@click.argument("group", type=click.Choice(DRAFT_GROUPS), required=False)
@click.pass_obj
def draft_show(rt: Runtime, group: str | None) -> None:
    """Show one draft or all drafts."""
    if group:
        rt.emit(rt.session.draft(group))
        return
    rt.emit({g: rt.session.draft(g) for g in DRAFT_GROUPS})


@draftgrp.command("clear")
@click.argument("group", type=click.Choice(DRAFT_GROUPS))
@click.pass_obj
def draft_clear(rt: Runtime, group: str) -> None:
    """Clear one draft."""
    n = rt.session.draft_clear(group)
    rt.save()
    rt.emit({"cleared": n})


@cli.command("status")
@click.pass_obj
def status(rt: Runtime) -> None:
    """Session summary: server, login, draft counts."""
    if rt.json_mode:
        snap = rt.session.snapshot()
        rt.emit({"server": snap.get("server"),
                 "logged_in": rt.session.is_logged_in,
                 "user": rt.session.user,
                 "draft_counts": {g: len(rt.session.draft(g)) for g in DRAFT_GROUPS}})
    else:
        click.echo(rt.session.summary())


def _repl_once(rt: Runtime, line: str) -> None:
    """Execute one REPL line through the same Click command tree."""
    args = shlex.split(line)
    if not args:
        return
    if args[0] in ("exit", "quit"):
        raise SystemExit(0)
    if args[0] == "--json":
        rt.json_mode = True
        args = args[1:] or ["--help"]
    try:
        cli.main(args=args, prog_name=CLI_NAME, standalone_mode=False)
    except SystemExit as exc:  # click uses SystemExit for usage errors
        if exc.code not in (0, None):
            click.echo(f"usage error (exit {exc.code})", err=True)
    except click.ClickException as exc:
        exc.show()
    except (WmsError, WmsTransportError) as exc:
        click.echo(f"API failure: {exc}", err=True)
    except ValueError as exc:
        click.echo(f"error: {exc}", err=True)


@cli.command()
@click.pass_obj
def repl(rt: Runtime) -> None:
    """Interactive REPL mode (also entered when invoked with no arguments)."""
    banner = (f"{CLI_NAME} {__version__} — interactive mode\n"
              f"server: {rt.session.base_url}  logged in: {rt.session.is_logged_in}\n"
              "type 'help' for commands, 'exit' to quit")
    click.echo(banner)
    while True:
        try:
            line = click.prompt(click.style("wms>", fg="cyan"), prompt_suffix=" ")
        except (EOFError, KeyboardInterrupt):
            click.echo()
            return
        try:
            _repl_once(rt, line)
        except SystemExit:
            return


def main() -> None:
    """Console entry point: REPL when invoked with no arguments on a TTY."""
    if not sys.argv[1:] and sys.stdin.isatty():
        cli.main(args=["repl"], prog_name=CLI_NAME)
        return
    cli(auto_envvar_prefix="WMS")


if __name__ == "__main__":
    main()
