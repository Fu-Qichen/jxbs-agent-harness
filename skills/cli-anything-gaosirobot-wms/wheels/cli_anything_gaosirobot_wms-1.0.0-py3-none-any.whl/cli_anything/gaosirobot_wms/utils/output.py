"""Output helpers: human tables, JSON mode, exit-code discipline."""

from __future__ import annotations

import datetime as _dt
import json
import sys
from typing import Any


def today() -> str:
    return _dt.date.today().isoformat()


def to_json_payload(ok: bool, code: int | None, msg: str | None, data: Any) -> str:
    return json.dumps({"ok": ok, "code": code, "msg": msg or "", "data": data},
                      ensure_ascii=False, default=str)


def emit_json(ok: bool, code: int | None, msg: str | None, data: Any) -> None:
    print(to_json_payload(ok, code, msg, data))


def _fmt(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def print_table(rows: list[dict], columns: list[str] | None = None) -> None:
    """Minimal dependency-free table for agent-readable output."""
    if not rows:
        print("(no rows)")
        return
    if columns is None:
        seen: list[str] = []
        for row in rows:
            for key in row:
                if key not in seen:
                    seen.append(key)
        columns = seen
    table = [[_fmt(row.get(c)) for c in columns] for row in rows]
    widths = [max(len(c), *(len(r[i]) for r in table)) if table else len(c)
              for i, c in enumerate(columns)]
    head = "  ".join(c.ljust(widths[i]) for i, c in enumerate(columns))
    print(head)
    print("  ".join("-" * w for w in widths))
    for r in table:
        print("  ".join(v.ljust(widths[i]) for i, v in enumerate(r)))


def emit_value(value: Any) -> None:
    """Human rendering of an arbitrary API payload."""
    if isinstance(value, list):
        if all(isinstance(r, dict) for r in value):
            print_table(value)
        else:
            for item in value:
                print(_fmt(item))
    elif isinstance(value, dict):
        width = max((len(k) for k in value), default=0)
        for key, val in value.items():
            print(f"{key.ljust(width)}  {_fmt(val)}")

def fail(message: str, code: int | None = None, data: Any = None,
         json_mode: bool = False) -> None:
    """Print an error and exit 1. Honors --json mode for agents."""
    if json_mode:
        emit_json(False, code, message, data)
    else:
        print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)
