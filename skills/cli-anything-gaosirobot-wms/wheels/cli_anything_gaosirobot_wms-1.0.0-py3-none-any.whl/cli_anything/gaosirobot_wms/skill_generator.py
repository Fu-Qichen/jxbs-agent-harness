"""Generate SKILL.md from the Click command tree (no hardcoded command list).

Usage: python skill_generator.py [--out skills/cli-anything-gaosirobot-wms/SKILL.md]

Outputs:
- canonical skill: <repo-root>/skills/cli-anything-gaosirobot-wms/SKILL.md
- packaged compatibility copy: cli_anything/gaosirobot_wms/skills/SKILL.md
"""

from __future__ import annotations

import argparse
from pathlib import Path

import click

from cli_anything.gaosirobot_wms import CLI_NAME, __version__
from cli_anything.gaosirobot_wms.gaosirobot_wms_cli import cli

HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parent.parent          # agent-harness/
SOFTWARE_ROOT = REPO_ROOT.parent        # gaosirobot-wms-app/


def format_option(opt) -> str:
    if opt.name in ("help",):
        return ""
    names = ", ".join(opt.opts + opt.secondary_opts)
    req = " (required)" if opt.required else ""
    takes_value = opt.type is not None and not isinstance(opt.type, click.types.BoolParamType)
    arg = f" {opt.name.upper()}" if takes_value else ""
    return f"`{names}{arg}`{req}"



def command_signature(full_path: str, cmd: click.Command) -> str:
    parts = [full_path]
    params = []
    for p in cmd.params:
        if isinstance(p, click.Argument):
            if p.required:
                parts.append(p.name.upper())
            else:
                parts.append(f"[{p.name.upper()}]")
        elif isinstance(p, click.Option):
            formatted = format_option(p)
            if formatted:
                params.append(formatted)
    return " ".join(parts) + (f"\n  Options: {'; '.join(params)}" if params else "")


def doc_first_line(cmd: click.Command) -> str:
    return (cmd.help or "").strip().splitlines()[0] if cmd.help else ""


def collect(group: click.Group, path: str = "") -> list[tuple[str, click.Command]]:
    rows = []
    for name, sub in sorted(group.commands.items()):
        full = f"{path}{name}"
        if isinstance(sub, click.Group):
            rows.append((full, sub))
            rows.extend(collect(sub, full + " "))
        else:
            rows.append((full, sub))
    return rows


def render() -> str:
    lines: list[str] = []
    lines.append("---")
    lines.append(f"name: {CLI_NAME}")
    lines.append(f"description: Stateful CLI harness for the Gaosi WMS backend "
                 f"(gaosirobot-wms-app): purchasing, transfers, finished-goods inbound, "
                 f"sales, returns, package trace, and messages via REST.")
    lines.append(f"version: {__version__}")
    lines.append("---")
    lines.append("")
    lines.append(f"# {CLI_NAME}")
    lines.append("")
    lines.append("CLI harness for the **Gaosi WMS** mobile app backend. Stateful: server "
                 "environment, auth token, and per-workflow scan drafts persist in a "
                 "session file (`~/.cli-anything/gaosirobot-wms/session.json`, override "
                 "with `CLI_ANYTHING_WMS_SESSION`). One-shot mutations auto-save; "
                 "`--dry-run` suppresses persistence and submission.")
    lines.append("")
    lines.append("## Global flags")
    lines.append("")
    lines.append("- `--json` (or `CLI_ANYTHING_JSON=1`) — machine-readable "
                 "`{\"ok\", \"code\", \"msg\", \"data\"}` output; exit 0 on success "
                 "(backend confirm code 250 counts as success), exit 1 on error.")
    lines.append("- `--dry-run` — build payloads without submitting or saving.")
    lines.append("- REPL: run with no arguments on a TTY, or use the `repl` command.")
    lines.append("")
    lines.append("## Authentication")
    lines.append("")
    lines.append("```bash")
    lines.append(f"{CLI_NAME} server use custom --url http://<host>:30001")
    lines.append(f"{CLI_NAME} server probe")
    lines.append(f"{CLI_NAME} auth login -u admin            # WMS_PASSWORD env or prompt")
    lines.append(f"{CLI_NAME} auth whoami")
    lines.append("```")
    lines.append("")
    lines.append("## Commands")
    lines.append("")

    current_group = None
    for full, cmd in collect(cli):
        group_name = full.split(" ")[0] if " " in full else None
        if isinstance(cmd, click.Group):
            current_group = full
            lines.append(f"### {full}")
            lines.append("")
            lines.append(f"{doc_first_line(cmd)}")
            lines.append("")
            continue
        lines.append(f"- `{CLI_NAME} {command_signature(full, cmd)}` — {doc_first_line(cmd)}")
    lines.append("")
    lines.append("## Workflows")
    lines.append("")
    lines.append("### Purchase inbound (scan → draft → submit)")
    lines.append("")
    lines.append("```bash")
    lines.append(f"{CLI_NAME} purchasing inbound-scan PKG001 --pos P01")
    lines.append(f"{CLI_NAME} purchasing inbound-list")
    lines.append(f"{CLI_NAME} purchasing inbound-submit --date 2026-09-07   "
                 "# auto-clears draft")
    lines.append("```")
    lines.append("")
    lines.append("### Production transfer")
    lines.append("")
    lines.append("```bash")
    lines.append(f"{CLI_NAME} transfer mo MO-0023")
    lines.append(f"{CLI_NAME} transfer scan PKGA --pos-in IN1")
    lines.append(f"{CLI_NAME} transfer submit MO-0023 --wh-out WH01 --wh-in WH02")
    lines.append("```")
    lines.append("")
    lines.append("### Agent guidance")
    lines.append("")
    lines.append("- Read state with `status` / `draft show` before mutating; submit only "
                 "after reviewing the draft.")
    lines.append("- Use `--dry-run` on submit commands to inspect the exact payload.")
    lines.append("- On `code: 401` in `--json` output, re-run `auth login`.")
    lines.append("- Unmapped endpoints: `request GET /MyClass/MyApi/... -q Key=Value`.")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=None, help="alternate canonical output path")
    args = parser.parse_args()

    content = render()
    canonical = Path(args.out) if args.out else (
        SOFTWARE_ROOT / "skills" / CLI_NAME / "SKILL.md")
    canonical.parent.mkdir(parents=True, exist_ok=True)
    canonical.write_text(content, encoding="utf-8")

    packaged_dir = HERE / "skills"
    packaged_dir.mkdir(exist_ok=True)
    (packaged_dir / "SKILL.md").write_text(content, encoding="utf-8")
    print(f"wrote {canonical}")
    print(f"wrote {packaged_dir / 'SKILL.md'}")


if __name__ == "__main__":
    main()
