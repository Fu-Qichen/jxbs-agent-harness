"""End-to-end tests: real CLI over real HTTP against an in-process fake WMS backend.

The fake server implements every endpoint mapped from ``src/api/*.ts`` with the
backend's envelope dialect, a Bearer-token auth guard, and request recording so
tests assert exactly what the CLI submitted.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pytest

from cli_anything.gaosirobot_wms.core.client import WmsClient

SRC_ROOT = Path(__file__).resolve().parents[3]  # .../agent-harness
CLI_MODULE_DIR = SRC_ROOT
CLI_NAME = "cli-anything-gaosirobot-wms"

TOKEN = "TESTTOKEN123"


def _envelope(data=None, code=0, msg="ok"):
    return {"code": code, "msg": msg, "data": data}


class FakeWmsHandler(BaseHTTPRequestHandler):
    """Stateful fake of the Gaosi WMS backend."""

    server_version = "FakeWMS/1.0"

    # -- plumbing -------------------------------------------------------

    def log_message(self, *args):  # silence
        pass

    @property
    def state(self) -> dict:
        return self.server.state

    def _send(self, payload, http_status=200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(http_status)
        self.send_header("Content-Type", "application/json;charset=UTF-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _authed(self) -> bool:
        return self.headers.get("Authorization") == f"Bearer {TOKEN}"

    def _query(self) -> dict:
        return {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if not length:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def _route(self, method: str):
        url = urlparse(self.path)
        path = url.path
        query = self._query()
        state = self.state
        state["requests"].append((method, path, dict(query)))

        # -- auth endpoints (no token required) --
        if method == "POST" and path == "/MobileLogin":
            body = self._body()
            if body.get("username") == "admin" and body.get("password") == "admin123":
                return self._send(_envelope(TOKEN))
            return self._send(_envelope(None, 400, "用户名或密码错误"))

        if method == "GET" and path == "/__state":
            return self._send({"code": 0, "msg": "ok", "data": dict(state)})
        if method == "POST" and path == "/LogOut":
            state["logged_out"] = True
            return self._send(_envelope(None))
        if path == "/getInfo":
            if not self._authed():
                return self._send(_envelope(None, 401, "未授权"), 200)
            return self._send(_envelope({
                "user": {"userId": 1, "userName": "admin", "nickName": "管理员"},
                "roles": ["common"], "permissions": [],
            }))

        # -- everything else requires a token --
        if not self._authed():
            return self._send(_envelope(None, 401, "登录状态已过期"))

        # -- purchasing --
        if method == "GET" and path == "/MyClass/MyApi/GetDeliveryDoc":
            return self._send(_envelope({"cCode": query["cCode"], "cVenCode": "V01"}))
        if method == "GET" and path == "/MyClass/MyApi/GetPackageMin":
            return self._send(_envelope({"packCode": query["PackCode"]}))
        if method == "GET" and path == "/MyClass/MyApi/GetPackageMax":
            return self._send(_envelope([{"packCode": "S1"}, {"packCode": "S2"}]))
        if method == "GET" and path == "/MyClass/MyApi/GetPosition":
            return self._send(_envelope({"cPosCode": query["cPosCode"], "cWhCode": "WH01"}))
        if method == "GET" and path == "/MyClass/MyMethod/GetPositionList":
            return self._send(_envelope({"datas": [{"cPosCode": "P1"}], "page": {}}))
        if method == "GET" and path == "/MyClass/MyApi/GetPackageMin_CGRK":
            return self._send(_envelope({
                "cInvCode": "100101A1", "cInvName": "法兰盘", "cInvStd": "DN50",
                "cComUnitName": "个", "packCode": query["PackCode"], "packCodeMax": "MAX1",
                "poNo": "PO001", "poRowId": "9", "cBatch": "B001", "status": "合格",
                "qualifiedQuantity": 10, "cVenCode": "V001", "cVenName": "供应商一",
                "cWhCode": "WH01", "autoIdSrm": "S1",
            }))
        if method == "POST" and path == "/MyClass/MyApi/AddCGRK":
            state["addcgrk"] = self._body()
            return self._send(_envelope({"cCode": "CGRK0001"}))
        if method == "POST" and path == "/MyClass/MyApi/AddArrivalVouch":
            state["arrival"] = self._body()
            return self._send(_envelope({"cCode": "ARR0001"}))

        # -- transfers --
        if method == "GET" and path == "/MyClass/MyMethod/GetMomOrderDetail":
            return self._send(_envelope({
                "head": {"moCode": query["moCode"], "cInvCode": "FG1", "iQuantity": 5},
                "body": [{"cInvCode": "M1", "iQuantity": 2}],
            }))
        if method == "POST" and path == "/MyClass/MyApi/ScanDBDPackCode":
            body = self._body()
            if body["currentPackCode"] in body["packCodes"]:
                return self._send(_envelope(None, 400, "包装已扫描"))
            state["scans"].append(body)
            return self._send(_envelope({
                "cInvCode": "M1", "cInvName": "物料", "cInvStd": "S", "cComUnitName": "个",
                "packCode": body["currentPackCode"], "packCodeMax": "PM",
                "cPosCode": "OUT1", "cBatch": "B", "iQuantity": 3,
            }))
        if method == "GET" and path == "/MyClass/MyApi/ScanDBDPackCodeBack":
            return self._send(_envelope({"packCode": query["PackCode"]}))
        if method == "POST" and path == "/MyClass/MyApi/AddDBDMom":
            state["add_dbd_mom"] = self._body()
            return self._send(_envelope({"cCode": "DBD0001"}))
        if method == "GET" and path == "/MyClass/MyMethod/GetWareHouseList":
            return self._send(_envelope({
                "datas": [{"cWhCode": "WH01", "cWhName": "原料库"},
                          {"cWhCode": "WH02", "cWhName": "成品库"}],
                "page": {},
            }))
        if method == "POST" and path == "/MyClass/MyApi/ScanDBDPackCode2":
            body = self._body()
            state["scans2"].append(body)
            return self._send(_envelope({
                "cInvCode": "M2", "cInvName": "物料2", "cInvStd": "S2",
                "cComUnitName": "个", "packCode": body["PackCode"]["currentPackCode"],
                "packCodeMax": "PM2", "cPosCode": "OUT2", "cBatch": "B2", "iQuantity": 1,
            }))
        if method == "POST" and path == "/MyClass/MyApi/AddDBD":
            state["add_dbd"] = self._body()
            return self._send(_envelope({"cCode": "DBD0002"}))

        # -- finished goods --
        if method == "GET" and path == "/MyClass/MyApi/GetPosition_CCPRK":
            return self._send(_envelope({"cPosCode": "FP1", "cPosName": "成品区",
                                         "cWhCode": "WH02", "cParentCode": ""}))
        if method == "GET" and path == "/MyClass/MyApi/GetMaterial_CCPRK":
            return self._send(_envelope({
                "barCode": "BC001", "barCodeUnder": query["barCodeUnder"],
                "cInvCode": "FG1", "cInvName": "成品", "cInvStd": "S",
                "cComUnitName": "件", "iQuantity": 2, "moCode": "MO-0023",
                "moDId": "D1", "cPosCode": "", "cPosName": "",
            }))
        if method == "POST" and path == "/MyClass/MyApi/AddCCPRK":
            state["add_ccprk"] = self._body()
            return self._send(_envelope(None))

        # -- sales --
        if method == "GET" and path == "/MyClass/MyApi/GetU9CShipPlanList":
            return self._send(_envelope({"datas": [
                {"head": {"id": 1, "cCode": "SP001", "dDate": "2026-09-07"},
                 "body": [{"itemInfoItemCode": "FG1", "planQtyIU": 9}]},
            ]}))
        if method == "POST" and path == "/MyClass/MyApi/AddXSCK":
            state["add_xsck"] = query
            return self._send(_envelope(None))
        if method == "GET" and path == "/MyClass/MyApi/GetWmsXSCKList":
            return self._send(_envelope({"datas": [
                {"head": {"cCode": "XSCK001", "dDate": "2026-09-07"}, "body": []},
            ]}))
        if method == "POST" and path == "/MyClass/MyApi/ConfirmXSCK":
            state["confirm_xsck"] = query
            # code 250: confirm-then-proceed path
            return self._send(_envelope({"confirmed": True}, code=250, msg="确认出库?"))

        # -- returns / trace / messages --
        if method == "GET" and path == "/MyClass/MyApi/GetPackageMin_CGJS":
            return self._send(_envelope({
                "arrivalVouchsAutoId": 7, "arrivalVouchCode": "ARR1", "cCodeSRM": "SRM1",
                "cInvCode": "M1", "cInvName": "物料", "cInvStd": "S", "cComUnitName": "个",
                "packCode": query["PackCode"], "packCodeMax": "PM", "poNo": "PO",
                "poRowId": "1", "cBatch": "B", "status": "不合格", "iQuantity": 5,
                "qualifiedQuantity": 0, "cVenCode": "V", "cVenName": "供应商",
                "cWhCode": "WH01",
            }))
        if method == "POST" and path == "/MyClass/MyApi/AddCGJS":
            state["add_cgjs"] = self._body()
            return self._send(_envelope(None))
        if method == "GET" and path == "/MyClass/MyApi/GetPackageMin_CGTH":
            return self._send(_envelope({"packCode": query["PackCode"], "iQuantity": 4,
                                         "cInvCode": "M1"}))
        if method == "POST" and path == "/MyClass/MyApi/AddCGTH":
            state["add_cgth"] = self._body()
            return self._send(_envelope(None))
        if method == "GET" and path == "/MyClass/MyApi/GetPackageMinStaus":
            return self._send(_envelope({"packCode": query["PackCode"],
                                         "status": "在库", "cWhCode": "WH01"}))
        if method == "GET" and path == "/SysUserMsg/mylist":
            return self._send(_envelope({
                "pageSize": 10, "pageIndex": 1, "totalNum": 1, "totalPage": 1,
                "result": [{"msgId": "1", "content": "hello", "isRead": False,
                            "msgType": "sys", "addTime": "2026-09-07"}],
                "extra": {},
            }))
        if method == "POST" and path.startswith("/SysUserMsg/read/"):
            parts = path.strip("/").split("/")
            state["read_msg"] = (parts[2], parts[3])
            return self._send(_envelope(None))

        return self._send(_envelope(None, 404, f"no route: {method} {path}"), 404)

    def do_GET(self):
        self._route("GET")

    def do_POST(self):
        self._route("POST")


@pytest.fixture(scope="module")
def fake_server():
    server = ThreadingHTTPServer(("127.0.0.1", 0), FakeWmsHandler)
    server.state = {"requests": [], "scans": [], "scans2": [], "logged_out": False}
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_address[1]}"
    server.shutdown()


def run_cli(args: list[str], session_file: Path, json_mode=True, cwd=None):
    env = dict(os.environ)
    env["CLI_ANYTHING_WMS_SESSION"] = str(session_file)
    env.pop("WMS_PASSWORD", None)
    if json_mode:
        env["CLI_ANYTHING_JSON"] = "1"
    else:
        env.pop("CLI_ANYTHING_JSON", None)
    proc = subprocess.run(
        [sys.executable, "-m", "cli_anything.gaosirobot_wms.gaosirobot_wms_cli", *args],
        capture_output=True, text=True, env=env,
        cwd=cwd or str(CLI_MODULE_DIR),
    )
    return proc


def parse_json(proc):
    assert proc.returncode == 0, f"exit={proc.returncode} stderr={proc.stderr}"
    return json.loads(proc.stdout.strip().splitlines()[-1])


@pytest.fixture
def fresh_session(tmp_path, fake_server):
    path = tmp_path / "session.json"
    path.write_text(json.dumps({"server": {"environment": "custom",
                                           "base_url": fake_server}}),
                    encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# B. E2E workflows
# ---------------------------------------------------------------------------


def test_server_switch_and_probe(fake_server, fresh_session):
    out = parse_json(run_cli(["server", "use", "custom", "--url", fake_server],
                             fresh_session))
    assert out["ok"] and out["data"]["base_url"] == fake_server
    out = parse_json(run_cli(["server", "probe"], fresh_session))
    assert out["data"]["reachable"] is True
    # server switch cleared login state
    out = parse_json(run_cli(["auth", "status"], fresh_session))
    assert out["data"]["logged_in"] is False


def test_login_logout_whoami(fake_server, fresh_session):
    out = parse_json(run_cli(["auth", "login", "-u", "admin", "-p", "admin123"],
                             fresh_session))
    assert out["ok"] and out["data"]["token"] == TOKEN
    out = parse_json(run_cli(["auth", "whoami"], fresh_session))
    assert out["data"]["user"]["userName"] == "admin"
    out = parse_json(run_cli(["auth", "logout"], fresh_session))
    assert out["ok"] and out["data"]["logged_in"] is False


def test_purchasing_inbound_payload_reaches_wire(fake_server, fresh_session):
    assert parse_json(run_cli(["auth", "login", "-u", "admin", "-p", "admin123"],
                              fresh_session))["ok"]
    parse_json(run_cli(["purchasing", "inbound-scan", "PKG009", "--pos", "P02"],
                       fresh_session))
    parse_json(run_cli(["purchasing", "inbound-submit", "--date", "2026-09-07",
                        "--user-code", "admin", "--user-name", "管理员"],
                       fresh_session))
    # read what the fake backend actually recorded
    state = WmsClient(fake_server).get("/__state")
    payload = state["addcgrk"]
    assert payload["dDate"] == "2026-09-07"
    assert payload["cVenCode"] == "V001"
    assert payload["cWhCode"] == "WH01"
    assert payload["createUserCode"] == "admin"
    row = payload["datas"][0]
    assert row["packCode"] == "PKG009" and row["cPosCode"] == "P02"
    assert row["iQuantity"] == "10"


def test_transfer_production_workflow(fake_server, fresh_session):
    assert parse_json(run_cli(["auth", "login", "-u", "admin", "-p", "admin123"],
                              fresh_session))["ok"]
    parse_json(run_cli(["transfer", "mo", "MO-0023"], fresh_session))
    parse_json(run_cli(["transfer", "scan", "PKGA", "--pos-in", "IN1"], fresh_session))
    parse_json(run_cli(["transfer", "scan", "PKGB", "--pos-in", "IN1"], fresh_session))
    out = parse_json(run_cli(["transfer", "submit", "MO-0023", "--wh-out", "WH01",
                              "--wh-in", "WH02", "--date", "2026-09-07"],
                             fresh_session))
    assert out["data"]["cCode"] == "DBD0001"
    out = parse_json(run_cli(["transfer", "list", "transfer"], fresh_session))
    assert out["data"] == []


def test_transfer_warehouse_workflow(fake_server, fresh_session):
    assert parse_json(run_cli(["auth", "login", "-u", "admin", "-p", "admin123"],
                              fresh_session))["ok"]
    out = parse_json(run_cli(["transfer", "warehouses"], fresh_session))
    assert [w["cWhCode"] for w in out["data"]] == ["WH01", "WH02"]
    parse_json(run_cli(["transfer", "scan2", "PKGC", "--wh-out", "WH01",
                        "--wh-in", "WH02", "--pos-in", "IN2"], fresh_session))
    out = parse_json(run_cli(["transfer", "submit-warehouse", "--wh-out", "WH01",
                              "--wh-in", "WH02", "--date", "2026-09-07"],
                             fresh_session))
    assert out["data"]["cCode"] == "DBD0002"


def test_finished_goods_workflow(fake_server, fresh_session):
    assert parse_json(run_cli(["auth", "login", "-u", "admin", "-p", "admin123"],
                              fresh_session))["ok"]
    out = parse_json(run_cli(["finished", "position"], fresh_session))
    assert out["data"]["cWhCode"] == "WH02"
    parse_json(run_cli(["finished", "material", "BCU001", "--pos", "FP1"],
                       fresh_session))
    out = parse_json(run_cli(["finished", "submit", "--wh", "WH02",
                              "--date", "2026-09-07"], fresh_session))
    assert out["ok"] is True


def test_sales_plan_and_outbound(fake_server, fresh_session):
    assert parse_json(run_cli(["auth", "login", "-u", "admin", "-p", "admin123"],
                              fresh_session))["ok"]
    out = parse_json(run_cli(["sales", "plans"], fresh_session))
    assert out["data"][0]["head"]["cCode"] == "SP001"
    out = parse_json(run_cli(["sales", "plan-submit", "SP001"], fresh_session))
    assert out["ok"]
    out = parse_json(run_cli(["sales", "outbounds"], fresh_session))
    assert out["data"][0]["head"]["cCode"] == "XSCK001"
    out = parse_json(run_cli(["sales", "outbound-confirm", "XSCK001"],
                             fresh_session))
    # code 250 confirm counts as success
    assert out["ok"] and out["data"]["confirmed"] is True
    assert out["code"] == 250


def test_purchase_reject_workflow(fake_server, fresh_session):
    assert parse_json(run_cli(["auth", "login", "-u", "admin", "-p", "admin123"],
                              fresh_session))["ok"]
    parse_json(run_cli(["returns", "reject-scan", "PKGR"], fresh_session))
    out = parse_json(run_cli(["returns", "reject-submit", "--reason", "破损",
                              "--date", "2026-09-07"], fresh_session))
    assert out["ok"]
    out = parse_json(run_cli(["returns", "list", "reject"], fresh_session))
    assert out["data"] == []


def test_return_and_trace(fake_server, fresh_session):
    assert parse_json(run_cli(["auth", "login", "-u", "admin", "-p", "admin123"],
                              fresh_session))["ok"]
    parse_json(run_cli(["returns", "return-scan", "PKGT"], fresh_session))
    out = parse_json(run_cli(["returns", "return-submit", "--reason", "退货",
                              "--date", "2026-09-07"], fresh_session))
    assert out["ok"]
    out = parse_json(run_cli(["trace", "PKGT"], fresh_session))
    assert out["data"]["status"] == "在库"


def test_messages_flow(fake_server, fresh_session):
    assert parse_json(run_cli(["auth", "login", "-u", "admin", "-p", "admin123"],
                              fresh_session))["ok"]
    out = parse_json(run_cli(["messages", "list"], fresh_session))
    assert out["data"][0]["msgId"] == "1"
    out = parse_json(run_cli(["messages", "read", "1", "sys"], fresh_session))
    assert out["ok"]


def test_json_mode_and_exit_codes(fake_server, fresh_session):
    # bad login -> exit 1 with json error envelope
    proc = run_cli(["auth", "login", "-u", "admin", "-p", "wrong"], fresh_session)
    assert proc.returncode == 1
    body = json.loads(proc.stdout.strip().splitlines()[-1])
    assert body["ok"] is False and body["code"] == 400
    # unknown route -> API error, exit 1
    proc = run_cli(["request", "GET", "/nope"], fresh_session)
    assert proc.returncode == 1


def test_401_prompts_relogin(fake_server, tmp_path):
    session_file = tmp_path / "session.json"
    session_file.write_text(
        json.dumps({"server": {"environment": "custom", "base_url": fake_server},
                    "token": "EXPIRED"}), encoding="utf-8")
    proc = run_cli(["auth", "whoami"], session_file)
    assert proc.returncode == 1
    body = json.loads(proc.stdout.strip().splitlines()[-1])
    assert body["ok"] is False and body["code"] == 401
    assert "auth login" in body["msg"]


# ---------------------------------------------------------------------------
# C. installed-console-script subprocess tests
# ---------------------------------------------------------------------------

def run_installed(args, session_file, cwd):
    env = dict(os.environ)
    env["CLI_ANYTHING_WMS_SESSION"] = str(session_file)
    env["CLI_ANYTHING_JSON"] = "1"
    if not shutil.which(CLI_NAME):
        # source fallback: expose the namespace package to the subprocess
        env["PYTHONPATH"] = str(CLI_MODULE_DIR) + os.pathsep + env.get("PYTHONPATH", "")
    return subprocess.run(TestCLISubprocess._resolve_cli(CLI_NAME) + args,
                          capture_output=True, text=True, env=env, cwd=str(cwd))


class TestCLISubprocess:
    @staticmethod
    def _resolve_cli(name: str) -> list[str]:
        """Locate the installed console script; FORCE_INSTALLED forbids fallback."""
        exe = shutil.which(name)
        if exe:
            return [exe]
        if os.environ.get("CLI_ANYTHING_FORCE_INSTALLED") == "1":
            pytest.fail(f"{name} not found on PATH but CLI_ANYTHING_FORCE_INSTALLED=1")
        # source fallback (adds agent-harness to PYTHONPATH) so the suite
        # also runs before `pip install -e .`
        return [sys.executable, "-m", "cli_anything.gaosirobot_wms.gaosirobot_wms_cli"]


    def test_installed_cli_version(self, tmp_path):
        proc = run_installed(["--version"], tmp_path / "s.json", tmp_path)
        assert proc.returncode == 0
        assert CLI_NAME in proc.stdout

    def test_installed_cli_login_and_inbound_e2e(self, fake_server, tmp_path):
        session_file = tmp_path / "session.json"
        session_file.write_text("{}", encoding="utf-8")
        assert run_installed(["server", "use", "custom", "--url", fake_server],
                             session_file, tmp_path).returncode == 0
        assert run_installed(["auth", "login", "-u", "admin", "-p", "admin123"],
                             session_file, tmp_path).returncode == 0
        assert run_installed(["purchasing", "inbound-scan", "PKG777", "--pos", "P9"],
                             session_file, tmp_path).returncode == 0
        proc = run_installed(["purchasing", "inbound-submit", "--date", "2026-09-07"],
                             session_file, tmp_path)
        assert proc.returncode == 0, proc.stderr
        body = json.loads(proc.stdout.strip().splitlines()[-1])
        assert body["ok"] and body["data"]["cCode"] == "CGRK0001"
