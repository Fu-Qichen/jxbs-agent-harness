"""Unit tests for core modules — synthetic data, no external services.

The HTTP layer is exercised through monkeypatched ``requests.request`` so the
envelope contract of ``src/http/http.ts`` is verified directly.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from cli_anything.gaosirobot_wms.core import purchasing, finished, returns, transfer
from cli_anything.gaosirobot_wms.core.client import (
    WmsAuthError,
    WmsClient,
    WmsError,
)
from cli_anything.gaosirobot_wms.core.session import Session


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


class FakeResponse:
    def __init__(self, status_code: int, body) -> None:
        self.status_code = status_code
        self._body = body
        self.url = "http://fake"

    def json(self):
        if self._body is None:
            raise ValueError("no json")
        return self._body


def patch_transport(monkeypatch, status_code=200, body=None, capture=None):
    """Replace requests.request; optionally capture the outgoing request."""

    def fake_request(method, url, **kwargs):
        if capture is not None:
            capture.append({"method": method, "url": url, **kwargs})
        return FakeResponse(status_code, body)

    monkeypatch.setattr("cli_anything.gaosirobot_wms.core.client.requests.request",
                        fake_request)


PKG = {
    "cInvCode": "100101A1", "cInvName": "法兰盘", "packCode": "PKG001",
    "packCodeMax": "MAX01", "poNo": "PO001", "poRowId": "9", "cBatch": "B001",
    "qualifiedQuantity": 10, "autoIdSrm": "S1", "cInvStd": "DN50",
    "cComUnitName": "个", "cVenCode": "V001", "cVenName": "供应商一",
    "cWhCode": "WH01",
}


# ---------------------------------------------------------------------------
# A. client / envelope
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("code", [0, 200])
def test_client_success_codes(monkeypatch, code):
    patch_transport(monkeypatch, 200, {"code": code, "msg": "ok", "data": {"x": 1}})
    client = WmsClient("http://fake")
    assert client.get("/x") == {"x": 1}
    assert client.last_code == code


def test_client_confirm_code_250(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 250, "msg": "确认提交?", "data": [1, 2]})
    client = WmsClient("http://fake")
    assert client.get("/x") == [1, 2]
    assert client.last_code == 250
    assert client.last_msg == "确认提交?"


def test_client_business_error(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 400, "msg": "库存不足", "data": None})
    with pytest.raises(WmsError) as ei:
        WmsClient("http://fake").get("/x")
    assert ei.value.code == 400
    assert "库存不足" in ei.value.msg


@pytest.mark.parametrize("status,code", [(200, 401), (401, 200), (401, 401)])
def test_client_unauthorized(monkeypatch, status, code):
    patch_transport(monkeypatch, status, {"code": code, "msg": "过期", "data": None})
    with pytest.raises(WmsAuthError):
        WmsClient("http://fake").get("/x")


def test_client_http_error(monkeypatch):
    patch_transport(monkeypatch, 500, {"code": 500, "msg": "boom"})
    with pytest.raises(WmsError) as ei:
        WmsClient("http://fake").get("/x")
    assert ei.value.code == 500


def test_client_non_json_body(monkeypatch):
    patch_transport(monkeypatch, 200, "plain text")
    assert WmsClient("http://fake").get("/x") == "plain text"


def test_message_fallback_to_message_field(monkeypatch):
    patch_transport(monkeypatch, 200, {"code": 400, "message": "envelope msg key"})
    with pytest.raises(WmsError) as ei:
        WmsClient("http://fake").get("/x")
    assert ei.value.msg == "envelope msg key"


# ---------------------------------------------------------------------------
# A. token handling
# ---------------------------------------------------------------------------


def test_token_extraction():
    assert WmsClient.extract_token("TOKEN123") == "TOKEN123"
    double = {"accessToken": "A", "refreshToken": "R", "accessExpiresIn": 1,
              "refreshExpiresIn": 2}
    assert WmsClient.extract_token(double) == double
    with pytest.raises(WmsError):
        WmsClient.extract_token("")
    with pytest.raises(WmsError):
        WmsClient.extract_token({"nope": 1})


def test_bearer_header(monkeypatch):
    capture: list = []
    patch_transport(monkeypatch, 200, {"code": 0, "data": None}, capture)
    client = WmsClient("http://fake", token="TOKEN123")
    client.get("/x", {"q": "1"})
    assert capture[0]["headers"]["Authorization"] == "Bearer TOKEN123"


def test_double_token_bearer(monkeypatch):
    capture: list = []
    patch_transport(monkeypatch, 200, {"code": 0, "data": None}, capture)
    tok = {"accessToken": "A1", "refreshToken": "R1"}
    client = WmsClient("http://fake", token=tok)
    client.get("/x")
    assert capture[0]["headers"]["Authorization"] == "Bearer A1"
    assert client.refresh_token == "R1"

# ---------------------------------------------------------------------------
# A. session
# ---------------------------------------------------------------------------


def test_session_roundtrip(tmp_path: Path):
    path = tmp_path / "session.json"
    s1 = Session(path=path)
    s1.use_custom("10.0.0.9:30001")
    s1.token = "T"
    s1.draft_add("inbound", {"packCode": "P1"})
    s1.save()
    s2 = Session(path=path)
    assert s2.base_url == "http://10.0.0.9:30001"
    assert s2.is_logged_in
    assert s2.draft("inbound") == [{"packCode": "P1"}]


def test_session_server_presets(tmp_path: Path):
    s = Session(path=tmp_path / "s.json")
    assert s.use_preset("production") == "http://211.91.60.61:30001"
    assert s.use_preset("test") == "http://211.91.60.61:20001"
    with pytest.raises(ValueError):
        s.use_preset("staging")
    # custom without scheme is normalized, trailing slash stripped
    assert s.use_custom("https://host.example/") == "https://host.example"


def test_draft_operations(tmp_path: Path):
    s = Session(path=tmp_path / "s.json")
    i1 = s.draft_add("transfer", {"packCode": "A"})
    s.draft_add("transfer", {"packCode": "B"})
    s.draft_add("inbound", {"packCode": "C"})
    assert s.draft_popcodes("transfer") == ["A", "B"]
    removed = s.draft_remove("transfer", i1)
    assert removed["packCode"] == "A"
    assert s.draft_clear("transfer") == 1
    assert s.draft_clear("transfer") == 0
    with pytest.raises(ValueError):
        s.draft("nope")


def test_clear_auth(tmp_path: Path):
    s = Session(path=tmp_path / "s.json")
    s.token = {"accessToken": "A", "refreshToken": "R"}
    s.user = {"userName": "admin"}
    s.clear_auth()
    assert not s.is_logged_in and s.user is None


# ---------------------------------------------------------------------------
# A. payload builders
# ---------------------------------------------------------------------------


def test_build_inbound_request():
    payload = purchasing.build_inbound_request(
        [dict(PKG, cPosCode="POS1")], "2026-09-07", "admin", "Administrator")
    assert payload["dDate"] == "2026-09-07"
    assert payload["cVenCode"] == "V001"
    assert payload["cWhCode"] == "WH01"
    row = payload["datas"][0]
    assert row["cInvCode"] == "100101A1"
    assert row["iQuantity"] == "10"  # qualifiedQuantity stringified
    assert row["cPosCode"] == "POS1"


def test_build_inbound_requires_pos():
    with pytest.raises(ValueError):
        purchasing.build_inbound_request([], "2026-09-07", "a", "b")
    with pytest.raises(ValueError):
        purchasing.build_inbound_request([dict(PKG)], "2026-09-07", "a", "b",
                                         default_pos=None)


def test_build_reject_request_capital_datas():
    item = {"arrivalVouchsAutoId": 7, "arrivalVouchCode": "ARR1", "cCodeSRM": "SRM1",
            "cInvCode": "M1", "cInvName": "n", "cInvStd": "s", "cComUnitName": "u",
            "poNo": "PO", "poRowId": "1", "packCode": "P", "packCodeMax": "M",
            "cBatch": "B", "iQuantity": 5, "cVenCode": "V", "cVenName": "供应商"}
    payload = returns.build_reject_request([item], "2026-09-07", "质量", "memo",
                                           "admin", "Admin")
    assert "Datas" in payload and "datas" not in payload
    assert payload["Datas"][0]["arrivalVouchCode"] == "ARR1"
    assert payload["cVenCode"] == "V"


def test_build_transfer_request():
    item = {"cInvCode": "M", "cInvName": "n", "cInvStd": "s", "cComUnitName": "u",
            "packCode": "P", "packCodeMax": "PM", "cPosCode": "OUT1", "cBatch": "B",
            "iQuantity": 3, "cPosCodeIn": "IN1"}
    payload = transfer.build_transfer_request([item], "MO-0023", "WH1", "WH2",
                                              "2026-09-07", "admin", "Admin")
    assert payload["moCode"] == "MO-0023"
    row = payload["datas"][0]
    assert row["cPosCodeOut"] == "OUT1" and row["cPosCodeIn"] == "IN1"
    assert row["iQuantity"] == "3"
    with pytest.raises(ValueError):
        transfer.build_transfer_request([], "MO", "W1", "W2", "d", "a", "b")


def test_build_finished_request():
    item = {"cInvCode": "FG1", "cInvName": "成品", "cInvStd": "S", "cComUnitName": "件",
            "iQuantity": 2, "moCode": "MO-1", "moDId": "D1", "barCode": "BC",
            "barCodeUnder": "BCU", "cPosCode": "P1"}
    payload = finished.build_inbound_request([item], "WH9", "2026-09-07",
                                             "admin", "Admin")
    row = payload["datas"][0]
    assert payload["cWhCode"] == "WH9"
    assert row["barCodeUnder"] == "BCU"
    assert row["moDId"] == "D1"
    assert row["cBatch"] == "MO-1"  # GUI derives batch from the MO code


def test_build_return_request():
    item = {"packCode": "P1", "iQuantity": 4}
    payload = returns.build_return_request([item], "2026-09-07", "r", "m",
                                           "admin", "Admin")
    assert payload["datas"] == [{"packCode": "P1", "iQuantity": "4"}]


def test_inbound_json_roundtrip():
    payload = purchasing.build_inbound_request([dict(PKG, cPosCode="POS1")],
                                               "2026-09-07", "admin", "Admin")
    assert json.loads(json.dumps(payload)) == payload  # serializable
